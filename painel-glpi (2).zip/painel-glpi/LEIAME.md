# Painel de Atendimento GLPI

Painel web com gráficos configuráveis (pizza, rosca, polar, barras, barras empilhadas,
linhas, áreas, radar, cartões e tabelas) sobre os chamados dos técnicos do GLPI.
Os dados vêm da **API REST do GLPI**, configurada pela própria tela do painel.

## 1. Instalar o Docker (Rocky / Alma / RHEL)

```bash
dnf -y install dnf-plugins-core
dnf config-manager --add-repo https://download.docker.com/linux/centos/docker-ce.repo
dnf -y install docker-ce docker-ce-cli containerd.io docker-compose-plugin
systemctl enable --now docker
```

## 2. Subir o painel

Copie a pasta `painel-glpi` para o servidor (ex.: `/opt/painel-glpi`) e rode:

```bash
cd /opt/painel-glpi
nano docker-compose.yml        # troque PANEL_PASSWORD por uma senha sua
docker compose up -d --build
firewall-cmd --permanent --add-port=8080/tcp && firewall-cmd --reload
```

Acesse `http://IP_DO_SERVIDOR:8080` e entre com o usuário e a senha definidos no
`docker-compose.yml` (padrão: `admin` / `TroqueEstaSenha`). Esse administrador é criado
só na primeira execução; depois disso, os usuários são gerenciados pela tela do painel.

## 3. Configurar a API (primeiro acesso)

A tela de configurações abre sozinha. Preencha:

| Campo | Onde encontrar no GLPI |
|---|---|
| URL da API | `https://IP_DO_GLPI/apirest.php` |
| App Token | Configurar > Geral > API > (cliente da API) |
| User Token | Minhas configurações > Chaves de acesso remoto > Token da API |
| Perfil dos técnicos | Nome exato do perfil, ex.: `Technician` |

Clique em **Testar conexão** e depois em **Salvar configurações**.

Na mesma tela:

* **Tempo limite da API** (padrão 90 s) e **Tentativas** (padrão 3): se o GLPI estiver lento,
  aumente o tempo limite (ex.: 120 a 180 s). Entre as tentativas o painel espera 5 s, 10 s...
* **Atualizar dados a cada (min)**: com o GLPI sobrecarregado, use 30 minutos para reduzir a carga.

Se o GLPI não responder, o painel **continua mostrando os últimos dados** com um aviso amarelo
e tenta de novo depois de alguns minutos.
Se o certificado do GLPI estiver vencido, deixe **Verificar certificado SSL** desmarcado.

O cliente da API no GLPI precisa estar **ativo** e liberar o **IP do servidor do painel**.
O User Token deve ser de um usuário que enxergue **todas as entidades** e tenha leitura de
chamados, usuários e perfis (um Super-Admin dedicado à integração é o mais simples).

## 4. Personalizar os gráficos

* **Editar painel** > **Adicionar gráfico**: escolha a métrica, o tipo de gráfico, as cores,
  a largura e a altura.
* Em cada gráfico: ✎ edita, ← → muda a posição, ✕ remove.
* A paleta **Por significado (status/SLA)** usa verde para no prazo e vermelho para expirado.
* O filtro de **período** e de **técnicos** no topo vale para todos os gráficos.
* O layout fica salvo no servidor (pasta `data/`), igual para todos que acessarem.

## 5. Usuários do painel

Menu com o seu nome (canto superior direito):

* **Usuários do painel** (administradores): cadastrar, editar, trocar senha e remover usuários.
  * **Administrador**: edita o painel, as configurações da API e os usuários.
  * **Somente visualização**: consulta, filtra e exporta, sem alterar nada.
* **Alterar minha senha**: disponível para todos.
* **Sair**: encerra a sessão.

As senhas são gravadas com hash (PBKDF2) em `data/users.json`. Se perder o acesso de todos
os administradores, apague `data/users.json` e reinicie o contêiner: o administrador do
`docker-compose.yml` é recriado.

## 6. Exportar PDF e CSV

* **Exportar > PDF do painel**: todos os gráficos, com período, técnicos filtrados e data
  de geração. Tabelas saem completas, em quantas páginas forem necessárias.
* **Exportar > CSV dos chamados**: um chamado por linha (abertos no período, técnicos
  filtrados), com status, técnico, datas, prazo e situação do SLA, reabertura e tempo de solução.
* Botão **⤓** em cada gráfico: baixa só aquele gráfico em CSV ou PDF.

Os CSV usam ponto e vírgula e acentuação compatível com o Excel em português.

## 7. Pendências

Bloco de gráficos sobre os chamados que estão **Pendentes agora** (não depende do período):

* **Tempo médio**, **maior tempo** e **soma do tempo** em pendência, e quantos estão
  pendentes **há mais de 7 dias**.
* **Pendentes por tempo parado**: até 1 dia, 1 a 3, 3 a 7, 7 a 15, 15 a 30 e mais de 30 dias.
* **Soma e média do tempo em pendência por técnico**, em gráfico e na tabela
  "Pendências por técnico".
* **Chamados pendentes**: lista do parado há mais tempo ao mais recente, com o tempo
  pendente atual e o total já acumulado (somando pendências anteriores do mesmo chamado).

O tempo é contado em horas corridas a partir de quando o chamado entrou em Pendente
(campo "Data de início da espera" do GLPI). Painéis já personalizados recebem esse bloco
automaticamente no fim, uma única vez; depois você pode mover ou remover os gráficos.

## 8. Desempenho por técnico (apresentação)

Botão **Por técnico**, no topo do painel (abre em uma nova aba, endereço `/tecnico`).

* Escolha o **técnico** e o **período**. A página mostra somente os dados dele: indicadores
  comparados com a média da equipe (verde = melhor que a média, vermelho = pior), status,
  situação do SLA, evolução diária e as listas de chamados em aberto e com SLA expirado.
* **Setas ‹ ›** (ou as setas do teclado) passam para o técnico anterior ou o próximo, em
  ordem alfabética. Depois do último, volta ao primeiro.
* **▶ Apresentação** troca de técnico sozinho no intervalo escolhido (barra de espaço
  pausa ou continua). **Tela cheia** (tecla F) é ideal para TV.
* **Foto**: administradores usam "Adicionar foto" no cartão do técnico. A imagem é
  recortada em quadrado e reduzida automaticamente, e fica salva em `data/fotos/`.
* **Baixar PDF** gera o relatório do técnico exibido.
* Os cartões **Soma do tempo em pendência** e **Maior tempo em pendência** mostram os
  chamados pendentes dele agora; a lista "Chamados em aberto" traz a coluna "Pendente há".

Aparecem apenas os técnicos ativos no GLPI.

## 9. Comandos úteis

```bash
docker compose logs -f          # ver o que está acontecendo
docker compose restart          # reiniciar
docker compose up -d --build    # aplicar atualizações do painel
```

Os dados do GLPI ficam em cache pelo tempo definido em "Atualizar dados a cada (min)".
O botão **Atualizar dados** força uma nova leitura na hora.
