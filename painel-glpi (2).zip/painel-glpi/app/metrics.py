"""Definicao e calculo das metricas do painel."""
from collections import defaultdict
from datetime import datetime

STATUS = {1: "Novo", 2: "Em atendimento", 3: "Planejado", 4: "Pendente",
          5: "Aguardando aprovação", 6: "Fechado"}

# kind: series (1 serie), multi (varias series), kpi (numero), table (tabela)
METRICS = [
    # Indicadores (cartoes)
    {"id": "kpi_abertos", "group": "Indicadores", "kind": "kpi", "title": "Abertos no período",
     "help": "Chamados abertos no período selecionado."},
    {"id": "kpi_em_aberto", "group": "Indicadores", "kind": "kpi", "title": "Em aberto agora",
     "help": "Chamados não solucionados neste momento (ignora o período)."},
    {"id": "kpi_pendentes", "group": "Indicadores", "kind": "kpi", "title": "Pendentes agora",
     "help": "Chamados com status Pendente neste momento (ignora o período)."},
    {"id": "kpi_aguardando", "group": "Indicadores", "kind": "kpi", "title": "Aguardando aprovação",
     "help": "Chamados solucionados aguardando aprovação do cliente (ignora o período)."},
    {"id": "kpi_sla_expirado", "group": "Indicadores", "kind": "kpi", "title": "SLA expirado (em aberto)",
     "help": "Chamados em aberto com prazo de solução vencido (ignora o período)."},
    {"id": "kpi_fechados", "group": "Indicadores", "kind": "kpi", "title": "Fechados no período",
     "help": "Chamados fechados dentro do período."},
    {"id": "kpi_reabertos", "group": "Indicadores", "kind": "kpi", "title": "Reabertos",
     "help": "Chamados abertos no período com solução recusada pelo cliente."},
    {"id": "kpi_sla_percentual", "group": "Indicadores", "kind": "kpi", "title": "SLA cumprido",
     "help": "% de chamados solucionados no período dentro do prazo de solução."},
    {"id": "kpi_tempo_medio", "group": "Indicadores", "kind": "kpi", "title": "Tempo médio de solução",
     "help": "Média em horas úteis (calendário do GLPI) dos chamados solucionados no período."},
    {"id": "kpi_novos_sem_tecnico", "group": "Indicadores", "kind": "kpi", "title": "Novos sem técnico",
     "help": "Chamados novos ainda sem técnico atribuído (ignora filtros)."},

    # Visao geral
    {"id": "status_geral", "group": "Visão geral", "kind": "series", "title": "Chamados por status",
     "help": "Chamados abertos no período, agrupados pelo status atual."},
    {"id": "sla_geral", "group": "Visão geral", "kind": "series", "title": "Situação do SLA",
     "help": "Chamados abertos no período, agrupados pela situação do prazo de solução."},
    {"id": "evolucao", "group": "Visão geral", "kind": "multi", "title": "Abertos x Solucionados x Fechados",
     "help": "Evolução diária (ou mensal, em períodos acima de 2 meses)."},

    # Por tecnico
    {"id": "status_por_tecnico", "group": "Por técnico", "kind": "multi", "title": "Status por técnico",
     "help": "Chamados abertos no período, por técnico e status atual."},
    {"id": "em_aberto_por_tecnico", "group": "Por técnico", "kind": "series", "title": "Em aberto por técnico",
     "help": "Fila atual de cada técnico (ignora o período)."},
    {"id": "pendentes_por_tecnico", "group": "Por técnico", "kind": "series", "title": "Pendentes por técnico",
     "help": "Chamados Pendentes agora (ignora o período)."},
    {"id": "aguardando_por_tecnico", "group": "Por técnico", "kind": "series",
     "title": "Aguardando aprovação por técnico",
     "help": "Solucionados aguardando aprovação do cliente (ignora o período)."},
    {"id": "fechados_por_tecnico", "group": "Por técnico", "kind": "series", "title": "Fechados por técnico",
     "help": "Chamados fechados dentro do período."},
    {"id": "reabertos_por_tecnico", "group": "Por técnico", "kind": "series", "title": "Reabertos por técnico",
     "help": "Chamados abertos no período com solução recusada."},
    {"id": "sla_por_tecnico", "group": "Por técnico", "kind": "multi", "title": "SLA por técnico",
     "help": "Chamados com SLA abertos no período: no prazo x expirado."},
    {"id": "sla_percentual_por_tecnico", "group": "Por técnico", "kind": "series",
     "title": "% SLA cumprido por técnico",
     "help": "% de solucionados no período dentro do prazo."},
    {"id": "tempo_medio_por_tecnico", "group": "Por técnico", "kind": "series",
     "title": "Tempo médio de solução (h) por técnico",
     "help": "Média em horas úteis dos chamados solucionados no período."},
    {"id": "validacoes_por_tecnico", "group": "Por técnico", "kind": "series",
     "title": "Aguardando validação por técnico",
     "help": "Chamados em aberto com validação (aprovação de gestor) pendente."},

    # Pendencias (situacao atual: ignoram o periodo)
    {"id": "kpi_pendencia_media", "group": "Pendências", "kind": "kpi", "title": "Tempo médio em pendência",
     "help": "Média de há quanto tempo os chamados pendentes estão parados (ignora o período)."},
    {"id": "kpi_pendencia_maior", "group": "Pendências", "kind": "kpi", "title": "Maior tempo em pendência",
     "help": "O chamado pendente há mais tempo (ignora o período)."},
    {"id": "kpi_pendencia_total", "group": "Pendências", "kind": "kpi", "title": "Soma do tempo em pendência",
     "help": "Soma do tempo parado de todos os chamados pendentes agora (ignora o período)."},
    {"id": "kpi_pendentes_7dias", "group": "Pendências", "kind": "kpi", "title": "Pendentes há mais de 7 dias",
     "help": "Quantidade de chamados pendentes há mais de 7 dias (ignora o período)."},
    {"id": "pendencia_faixas", "group": "Pendências", "kind": "series", "title": "Pendentes por tempo parado",
     "help": "Chamados pendentes agrupados por há quanto tempo estão em pendência."},
    {"id": "pendencia_soma_por_tecnico", "group": "Pendências", "kind": "series",
     "title": "Soma do tempo em pendência por técnico (dias)",
     "help": "Soma, em dias, do tempo parado dos chamados pendentes de cada técnico."},
    {"id": "pendencia_media_por_tecnico", "group": "Pendências", "kind": "series",
     "title": "Tempo médio em pendência por técnico (dias)",
     "help": "Média, em dias, do tempo parado dos chamados pendentes de cada técnico."},
    {"id": "tabela_pendencia_tecnico", "group": "Pendências", "kind": "table",
     "title": "Pendências por técnico",
     "help": "Quantidade, soma, média e maior tempo em pendência dos chamados pendentes de cada técnico."},
    {"id": "tabela_pendentes", "group": "Pendências", "kind": "table", "title": "Chamados pendentes",
     "help": "Chamados pendentes agora, do parado há mais tempo ao mais recente."},

    # Tabelas
    {"id": "tabela_ranking", "group": "Tabelas", "kind": "table", "title": "Resumo por técnico",
     "help": "Principais indicadores de cada técnico."},
    {"id": "tabela_sla_expirado", "group": "Tabelas", "kind": "table", "title": "Chamados com SLA expirado",
     "help": "Chamados em aberto com prazo vencido, do mais atrasado ao menos atrasado."},
]

SLA_ORDEM = ["Solucionado no prazo", "Em aberto - no prazo", "Solucionado fora do prazo",
             "Em aberto - expirado", "Sem SLA"]


def _fmt(dt):
    return dt.strftime("%d/%m/%Y %H:%M") if dt else ""


FAIXAS_PENDENCIA = [(86400, "Até 1 dia"), (3 * 86400, "1 a 3 dias"), (7 * 86400, "3 a 7 dias"),
                    (15 * 86400, "7 a 15 dias"), (30 * 86400, "15 a 30 dias"), (None, "Mais de 30 dias")]


def duracao_txt(segundos):
    """Ex.: 3d 4h, 5h 20min, 12min."""
    if segundos is None:
        return "–"
    segundos = max(0, int(segundos))
    dias, resto = divmod(segundos, 86400)
    horas, resto = divmod(resto, 3600)
    minutos = resto // 60
    if dias:
        return f"{dias}d {horas}h"
    if horas:
        return f"{horas}h {minutos}min"
    return f"{minutos}min"


def em_dias(segundos):
    return round(segundos / 86400, 1)


def tempo_pendente(t, agora):
    """Ha quanto tempo o chamado esta no periodo de pendencia atual (tempo corrido)."""
    if t["status"] != 4 or t.get("begin_waiting") is None:
        return None
    return max(0, (agora - t["begin_waiting"]).total_seconds())


def _media_horas(valores):
    valores = [v for v in valores if v > 0]
    return round(sum(valores) / len(valores) / 3600, 1) if valores else 0


def _chaves_tempo(inicio, fim):
    mensal = (fim.date() - inicio.date()).days > 62
    chaves, rotulos = [], []
    if mensal:
        ano, mes = inicio.year, inicio.month
        while (ano, mes) <= (fim.year, fim.month):
            chaves.append(f"{ano:04d}-{mes:02d}")
            rotulos.append(f"{mes:02d}/{ano}")
            mes += 1
            if mes > 12:
                ano, mes = ano + 1, 1
        return chaves, rotulos, (lambda dt: dt.strftime("%Y-%m"))
    dia = inicio.date()
    while dia <= fim.date():
        chaves.append(dia.isoformat())
        rotulos.append(dia.strftime("%d/%m"))
        dia = dia.fromordinal(dia.toordinal() + 1)
    return chaves, rotulos, (lambda dt: dt.date().isoformat())


def calcular(dados, inicio, fim, filtro_tecnicos):
    agora = datetime.now()
    tecnicos = dados["techs"]
    sel = (set(filtro_tecnicos) & set(tecnicos)) if filtro_tecnicos else set(tecnicos)
    nomes = {u: tecnicos[u]["name"] for u in sel}
    ordem = sorted(sel, key=lambda u: nomes[u].lower())
    rot_tec = [nomes[u] for u in ordem]

    T = [t for t in dados["tickets"] if t["techs"] & sel]

    def no_periodo(dt):
        return dt is not None and inicio <= dt <= fim

    abertos = [t for t in T if no_periodo(t["date"])]
    solucionados = [t for t in T if t["status"] in (5, 6) and no_periodo(t["solvedate"])]
    fechados = [t for t in T if t["status"] == 6 and no_periodo(t["closedate"])]
    em_aberto = [t for t in T if t["status"] not in (5, 6)]

    def por_tecnico(lista, cond=lambda t: True):
        c = defaultdict(int)
        for t in lista:
            if cond(t):
                for u in t["techs"] & sel:
                    c[u] += 1
        return [c[u] for u in ordem]

    def serie(rotulos, valores, nome="Chamados"):
        return {"labels": rotulos, "datasets": [{"label": nome, "data": valores}]}

    def multi(rotulos, series):
        return {"labels": rotulos, "datasets": [{"label": n, "data": v} for n, v in series]}

    def situacao_sla(t):
        if t["ttr"] is None:
            return "Sem SLA"
        if t["status"] in (5, 6):
            ok = t["solvedate"] is not None and t["solvedate"] <= t["ttr"]
            return "Solucionado no prazo" if ok else "Solucionado fora do prazo"
        return "Em aberto - expirado" if agora > t["ttr"] else "Em aberto - no prazo"

    def sla_ok(t):
        return situacao_sla(t) in ("Solucionado no prazo", "Em aberto - no prazo")

    def pct_sla(lista):
        com = [t for t in lista if t["ttr"]]
        if not com:
            return None
        return round(100 * sum(1 for t in com if t["solvedate"] <= t["ttr"]) / len(com), 1)

    m = {}

    # ---------- Indicadores ----------
    m["kpi_abertos"] = {"value": len(abertos)}
    m["kpi_em_aberto"] = {"value": len(em_aberto)}
    m["kpi_pendentes"] = {"value": sum(1 for t in T if t["status"] == 4)}
    m["kpi_aguardando"] = {"value": sum(1 for t in T if t["status"] == 5)}
    m["kpi_sla_expirado"] = {"value": sum(1 for t in em_aberto if t["ttr"] and agora > t["ttr"])}
    m["kpi_fechados"] = {"value": len(fechados)}
    m["kpi_reabertos"] = {"value": sum(1 for t in abertos if t["refused"])}
    m["kpi_sla_percentual"] = {"value": pct_sla(solucionados), "suffix": "%"}
    m["kpi_tempo_medio"] = {"value": _media_horas([t["solve_delay"] for t in solucionados]), "suffix": " h"}
    m["kpi_novos_sem_tecnico"] = {"value": dados["unassigned_new"]}

    # ---------- Visao geral ----------
    cont = defaultdict(int)
    for t in abertos:
        cont[t["status"]] += 1
    st = [s for s in STATUS if cont[s]]
    m["status_geral"] = serie([STATUS[s] for s in st], [cont[s] for s in st])

    cont_sla = defaultdict(int)
    for t in abertos:
        cont_sla[situacao_sla(t)] += 1
    sl = [s for s in SLA_ORDEM if cont_sla[s]]
    m["sla_geral"] = serie(sl, [cont_sla[s] for s in sl])

    chaves, rotulos, chave = _chaves_tempo(inicio, fim)
    a, s, f = defaultdict(int), defaultdict(int), defaultdict(int)
    for t in abertos:
        a[chave(t["date"])] += 1
    for t in solucionados:
        s[chave(t["solvedate"])] += 1
    for t in fechados:
        f[chave(t["closedate"])] += 1
    m["evolucao"] = multi(rotulos, [("Abertos", [a[k] for k in chaves]),
                                    ("Solucionados", [s[k] for k in chaves]),
                                    ("Fechados", [f[k] for k in chaves])])

    # ---------- Por tecnico ----------
    m["status_por_tecnico"] = multi(rot_tec, [
        ("Em atendimento", por_tecnico(abertos, lambda t: t["status"] in (1, 2, 3))),
        ("Pendentes", por_tecnico(abertos, lambda t: t["status"] == 4)),
        ("Aguardando aprovação", por_tecnico(abertos, lambda t: t["status"] == 5)),
        ("Fechados", por_tecnico(abertos, lambda t: t["status"] == 6)),
    ])
    m["em_aberto_por_tecnico"] = serie(rot_tec, por_tecnico(em_aberto), "Em aberto")
    m["pendentes_por_tecnico"] = serie(rot_tec, por_tecnico(T, lambda t: t["status"] == 4), "Pendentes")
    m["aguardando_por_tecnico"] = serie(rot_tec, por_tecnico(T, lambda t: t["status"] == 5),
                                        "Aguardando aprovação")
    m["fechados_por_tecnico"] = serie(rot_tec, por_tecnico(fechados), "Fechados")
    m["reabertos_por_tecnico"] = serie(rot_tec, por_tecnico(abertos, lambda t: t["refused"]), "Reabertos")

    com_sla = [t for t in abertos if t["ttr"]]
    m["sla_por_tecnico"] = multi(rot_tec, [
        ("No prazo", por_tecnico(com_sla, sla_ok)),
        ("Expirado", por_tecnico(com_sla, lambda t: not sla_ok(t))),
    ])
    m["sla_percentual_por_tecnico"] = serie(
        rot_tec, [pct_sla([t for t in solucionados if u in t["techs"]]) or 0 for u in ordem],
        "% SLA cumprido")
    m["tempo_medio_por_tecnico"] = serie(
        rot_tec, [_media_horas([t["solve_delay"] for t in solucionados if u in t["techs"]]) for u in ordem],
        "Horas (média)")
    m["validacoes_por_tecnico"] = serie(
        rot_tec, por_tecnico(em_aberto, lambda t: t["waiting_validation"]), "Aguardando validação")

    # ---------- Tabelas ----------
    linhas = []
    for u in ordem:
        ab = [t for t in abertos if u in t["techs"]]
        so = [t for t in solucionados if u in t["techs"]]
        p = pct_sla(so)
        linhas.append([
            nomes[u],
            len(ab),
            sum(1 for t in fechados if u in t["techs"]),
            sum(1 for t in em_aberto if u in t["techs"]),
            sum(1 for t in T if u in t["techs"] and t["status"] == 4),
            sum(1 for t in T if u in t["techs"] and t["status"] == 5),
            sum(1 for t in ab if t["refused"]),
            "-" if p is None else f"{p}%",
            _media_horas([t["solve_delay"] for t in so]),
        ])
    m["tabela_ranking"] = {
        "columns": ["Técnico", "Abertos (período)", "Fechados (período)", "Em aberto agora",
                    "Pendentes", "Aguard. aprovação", "Reabertos", "SLA cumprido", "Tempo médio (h)"],
        "rows": linhas,
    }

    # ---------- Pendencias ----------
    pendentes = [(t, tempo_pendente(t, agora)) for t in T if t["status"] == 4]
    tempos = [s for _, s in pendentes if s is not None]
    media = sum(tempos) / len(tempos) if tempos else None
    m["kpi_pendencia_media"] = {"value": em_dias(media) if media is not None else None, "suffix": " dias",
                                "text": duracao_txt(media) if media is not None else None}
    maior = max(tempos) if tempos else None
    m["kpi_pendencia_maior"] = {"value": em_dias(maior) if maior is not None else None, "suffix": " dias",
                                "text": duracao_txt(maior) if maior is not None else None}
    total = sum(tempos)
    m["kpi_pendencia_total"] = {"value": em_dias(total), "suffix": " dias", "text": duracao_txt(total)}
    m["kpi_pendentes_7dias"] = {"value": sum(1 for s in tempos if s > 7 * 86400)}

    faixas = defaultdict(int)
    for s_ in tempos:
        for limite, nome in FAIXAS_PENDENCIA:
            if limite is None or s_ <= limite:
                faixas[nome] += 1
                break
    m["pendencia_faixas"] = serie([n for _, n in FAIXAS_PENDENCIA], [faixas[n] for _, n in FAIXAS_PENDENCIA],
                                  "Chamados pendentes")

    por_tec = defaultdict(list)
    for t, s_ in pendentes:
        for u in t["techs"] & sel:
            if s_ is not None:
                por_tec[u].append(s_)
    m["pendencia_soma_por_tecnico"] = serie(rot_tec, [em_dias(sum(por_tec[u])) for u in ordem], "Dias em pendência")
    m["pendencia_media_por_tecnico"] = serie(
        rot_tec, [em_dias(sum(por_tec[u]) / len(por_tec[u])) if por_tec[u] else 0 for u in ordem],
        "Média em dias")

    linhas_tec = []
    for u in sorted(ordem, key=lambda x: -sum(por_tec[x])):
        lista = por_tec[u]
        qtd = sum(1 for t, _ in pendentes if u in t["techs"])
        if not qtd:
            continue
        linhas_tec.append([nomes[u], qtd, duracao_txt(sum(lista)), em_dias(sum(lista)),
                           duracao_txt(sum(lista) / len(lista)) if lista else "–",
                           duracao_txt(max(lista)) if lista else "–",
                           sum(1 for x in lista if x > 7 * 86400)])
    m["tabela_pendencia_tecnico"] = {
        "columns": ["Técnico", "Pendentes", "Soma do tempo", "Soma (dias)", "Tempo médio", "Maior tempo",
                    "Há mais de 7 dias"],
        "rows": linhas_tec,
    }

    ordenados = sorted(pendentes, key=lambda x: -(x[1] or 0))
    m["tabela_pendentes"] = {
        "columns": ["Chamado", "Título", "Técnico(s)", "Pendente desde", "Tempo pendente",
                    "Total já pendente", "Prazo SLA"],
        "rows": [[t["id"], t["name"], ", ".join(sorted(nomes[u] for u in t["techs"] & sel)),
                  _fmt(t["begin_waiting"]), duracao_txt(s_),
                  duracao_txt((s_ or 0) + t.get("waiting_duration", 0)), _fmt(t["ttr"])]
                 for t, s_ in ordenados[:500]],
    }

    atrasados = sorted([t for t in em_aberto if t["ttr"] and agora > t["ttr"]], key=lambda t: t["ttr"])
    m["tabela_sla_expirado"] = {
        "columns": ["Chamado", "Título", "Técnico(s)", "Status", "Abertura", "Prazo SLA", "Atraso (h)"],
        "rows": [[t["id"], t["name"], ", ".join(sorted(nomes[u] for u in t["techs"] & sel)),
                  STATUS.get(t["status"], ""), _fmt(t["date"]), _fmt(t["ttr"]),
                  round((agora - t["ttr"]).total_seconds() / 3600, 1)] for t in atrasados[:500]],
    }
    return m


COLUNAS_CHAMADOS = ["Chamado", "Título", "Status", "Técnico(s)", "Abertura", "Solução", "Fechamento",
                    "Prazo SLA", "Situação SLA", "Reaberto", "Aguardando validação", "Tempo de solução (h)"]


def linhas_chamados(dados, inicio, fim, filtro_tecnicos):
    """Chamados abertos no periodo, um por linha, para exportacao em CSV."""
    agora = datetime.now()
    tecnicos = dados["techs"]
    sel = (set(filtro_tecnicos) & set(tecnicos)) if filtro_tecnicos else set(tecnicos)
    linhas = []
    for t in sorted(dados["tickets"], key=lambda x: x["id"]):
        if not (t["techs"] & sel) or t["date"] is None or not (inicio <= t["date"] <= fim):
            continue
        if t["ttr"] is None:
            sla = "Sem SLA"
        elif t["status"] in (5, 6):
            sla = "No prazo" if t["solvedate"] and t["solvedate"] <= t["ttr"] else "Expirado"
        else:
            sla = "Expirado" if agora > t["ttr"] else "No prazo"
        linhas.append([
            t["id"], t["name"], STATUS.get(t["status"], ""),
            ", ".join(sorted(tecnicos[u]["name"] for u in t["techs"] & sel)),
            _fmt(t["date"]), _fmt(t["solvedate"]), _fmt(t["closedate"]), _fmt(t["ttr"]), sla,
            "Sim" if t["refused"] else "Não", "Sim" if t["waiting_validation"] else "Não",
            round(t["solve_delay"] / 3600, 1) if t["solve_delay"] else "",
        ])
    return linhas


def resumo_por_tecnico(dados, inicio, fim):
    """Indicadores individuais de cada tecnico, usados na pagina 'Por tecnico' e na media da equipe."""
    agora = datetime.now()
    res = {}
    for uid in dados["techs"]:
        T = [t for t in dados["tickets"] if uid in t["techs"]]
        abertos = [t for t in T if t["date"] and inicio <= t["date"] <= fim]
        solucionados = [t for t in T if t["status"] in (5, 6) and t["solvedate"] and inicio <= t["solvedate"] <= fim]
        com_sla = [t for t in solucionados if t["ttr"]]
        res[uid] = {
            "abertos": len(abertos),
            "fechados": sum(1 for t in T if t["status"] == 6 and t["closedate"] and inicio <= t["closedate"] <= fim),
            "em_aberto": sum(1 for t in T if t["status"] not in (5, 6)),
            "pendentes": sum(1 for t in T if t["status"] == 4),
            "aguardando": sum(1 for t in T if t["status"] == 5),
            "reabertos": sum(1 for t in abertos if t["refused"]),
            "sla_expirado": sum(1 for t in T if t["status"] not in (5, 6) and t["ttr"] and agora > t["ttr"]),
            "sla_pct": round(100 * sum(1 for t in com_sla if t["solvedate"] <= t["ttr"]) / len(com_sla), 1) if com_sla else None,
            "tempo_medio": _media_horas([t["solve_delay"] for t in solucionados]),
            "pendencia_soma": sum(x for x in (tempo_pendente(t, agora) for t in T) if x is not None),
            "pendencia_maior": max((x for x in (tempo_pendente(t, agora) for t in T) if x is not None), default=None),
        }
    return res


def media_equipe(resumo, ids_ativos):
    """Media simples entre os tecnicos ativos (ignora indicadores sem dados)."""
    medias = {}
    for chave in ("abertos", "fechados", "em_aberto", "pendentes", "aguardando", "reabertos",
                  "sla_expirado", "sla_pct", "tempo_medio", "pendencia_soma", "pendencia_maior"):
        valores = [resumo[u][chave] for u in ids_ativos if u in resumo and resumo[u][chave] is not None]
        if chave == "tempo_medio":
            valores = [v for v in valores if v > 0]
        medias[chave] = round(sum(valores) / len(valores), 1) if valores else None
    return medias


def linhas_em_aberto(dados, uid):
    agora = datetime.now()
    linhas = []
    for t in sorted((t for t in dados["tickets"] if uid in t["techs"] and t["status"] not in (5, 6)),
                    key=lambda x: (x["ttr"] is None, x["ttr"] or x["date"] or agora)):
        if t["ttr"] is None:
            sla = "Sem SLA"
        else:
            sla = "Expirado" if agora > t["ttr"] else "No prazo"
        pend = tempo_pendente(t, agora)
        linhas.append([t["id"], t["name"], STATUS.get(t["status"], ""), _fmt(t["date"]), _fmt(t["ttr"]), sla,
                       duracao_txt(pend) if pend is not None else ""])
    return {"columns": ["Chamado", "Título", "Status", "Abertura", "Prazo SLA", "Situação SLA", "Pendente há"],
            "rows": linhas[:500]}
