/* Painel GLPI - pagina "Desempenho por tecnico" (apresentacao) */
(function () {
  "use strict";

  const $ = (s, el = document) => el.querySelector(s);
  const SIGNIFICADO = {
    "No prazo": "#2e8b57", "Expirado": "#c0392b", "Solucionado no prazo": "#2e8b57",
    "Em aberto - no prazo": "#7fcf9f", "Solucionado fora do prazo": "#d98e04",
    "Em aberto - expirado": "#c0392b", "Sem SLA": "#9aa8b3",
    "Novo": "#4f9fd1", "Em atendimento": "#1f7a8c", "Planejado": "#7d5ba6", "Pendente": "#d98e04",
    "Aguardando aprovação": "#f2b134", "Fechado": "#2e8b57",
    "Abertos": "#1f7a8c", "Solucionados": "#7d5ba6", "Fechados": "#2e8b57",
  };
  const RESERVA = ["#1f7a8c", "#12324a", "#d98e04", "#2e8b57", "#c0392b", "#7d5ba6", "#4f9fd1"];
  const cor = (rotulo, i) => SIGNIFICADO[rotulo] || RESERVA[i % RESERVA.length];

  const estado = { usuario: null, tecnicos: [], idx: 0, dados: null, graficos: [], tocando: false, timer: null };

  // ------------------------------------------------------------ utilitarios
  async function api(url, opcoes) {
    const r = await fetch(url, opcoes);
    if (r.status === 401) { window.location.href = "/login"; throw new Error("Sessão expirada."); }
    let j = null;
    try { j = await r.json(); } catch (e) { /* sem corpo */ }
    if (!r.ok) throw new Error((j && (j.detail || j.message)) || `Erro HTTP ${r.status}`);
    return j;
  }
  const fmtNum = (v) => (typeof v === "number" ? v.toLocaleString("pt-BR") : v);
  function fmtDur(seg) {
    if (seg === null || seg === undefined) return "–";
    const s = Math.max(0, Math.round(seg));
    const d = Math.floor(s / 86400), h = Math.floor((s % 86400) / 3600), m = Math.floor((s % 3600) / 60);
    if (d >= 10) return `${d}d`;
    if (d) return `${d}d ${h}h`;
    if (h) return `${h}h ${m}min`;
    return `${m}min`;
  }
  const iso = (d) => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
  const dataBR = (s) => (s ? s.split("-").reverse().join("/") : "");
  const salvarLocal = (k, v) => { try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) { /* ignora */ } };
  const lerLocal = (k, p) => { try { const v = localStorage.getItem(k); return v ? JSON.parse(v) : p; } catch (e) { return p; } };
  const ehAdmin = () => estado.usuario && estado.usuario.role === "admin";
  const atual = () => estado.tecnicos[estado.idx];
  const slug = (t) => t.normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase().replace(/[^a-z0-9]+/g, "_").replace(/^_+|_+$/g, "");
  const el = (tag, cls, texto) => { const e = document.createElement(tag); if (cls) e.className = cls; if (texto !== undefined) e.textContent = texto; return e; };

  function aviso(msg, tipo) {
    const a = $("#aviso"); a.hidden = !msg; a.textContent = msg || "";
    a.classList.toggle("alerta", tipo === "alerta");
  }
  let tempoToast = null;
  function toast(msg, ms = 3500) {
    const t = $("#toast"); t.textContent = msg; t.hidden = false;
    clearTimeout(tempoToast);
    if (ms) tempoToast = setTimeout(() => { t.hidden = true; }, ms);
  }

  function aplicarPreset(p) {
    const hoje = new Date();
    let ini = new Date(hoje), fim = new Date(hoje);
    if (p === "mes") ini = new Date(hoje.getFullYear(), hoje.getMonth(), 1);
    else if (p === "mes_ant") { ini = new Date(hoje.getFullYear(), hoje.getMonth() - 1, 1); fim = new Date(hoje.getFullYear(), hoje.getMonth(), 0); }
    else if (p === "ano") ini = new Date(hoje.getFullYear(), 0, 1);
    else if (p === "custom") return;
    else if (p !== "hoje") ini.setDate(hoje.getDate() - (parseInt(p, 10) - 1));
    $("#inicio").value = iso(ini);
    $("#fim").value = iso(fim);
  }

  // valores escritos sobre as fatias e barras
  const pluginValores = {
    id: "valores",
    afterDatasetsDraw(chart, args, opts) {
      if (!opts || !opts.enabled) return;
      const { ctx } = chart;
      const redondo = ["pie", "doughnut"].includes(chart.config.type);
      ctx.save();
      ctx.font = "600 11px 'Segoe UI', system-ui, sans-serif";
      ctx.textAlign = "center"; ctx.textBaseline = "middle";
      chart.data.datasets.forEach((ds, i) => {
        const meta = chart.getDatasetMeta(i);
        if (meta.hidden) return;
        meta.data.forEach((e, j) => {
          const v = ds.data[j];
          if (v === null || v === undefined || v === 0 || !chart.getDataVisibility(j)) return;
          const p = e.tooltipPosition();
          ctx.fillStyle = redondo ? "#ffffff" : "#1d2b36";
          ctx.fillText(fmtNum(v), p.x, redondo ? p.y : p.y - 9);
        });
      });
      ctx.restore();
    },
  };
  if (window.Chart) Chart.register(pluginValores);

  // ------------------------------------------------------------ montagem do slide
  function painel(classe, titulo) {
    const p = el("section", `painel ${classe}`);
    const topo = el("div", "painel-topo");
    topo.appendChild(el("h3", "painel-titulo", titulo));
    const corpo = el("div", "painel-corpo");
    p.append(topo, corpo);
    return { p, corpo };
  }

  function grafico(corpo, tipo, labels, datasets, extra = {}) {
    if (!labels.length || datasets.every((d) => d.data.every((v) => !v))) {
      corpo.appendChild(el("div", "vazio", "Nenhum chamado no período."));
      return;
    }
    const canvas = document.createElement("canvas");
    corpo.appendChild(canvas);
    const redondo = tipo === "pie" || tipo === "doughnut";
    const opcoes = {
      responsive: true, maintainAspectRatio: false, animation: { duration: 300 },
      plugins: {
        legend: { display: redondo || datasets.length > 1, position: redondo ? "right" : "bottom", labels: { boxWidth: 12, usePointStyle: true } },
        valores: { enabled: extra.valores !== false && tipo !== "line" },
      },
    };
    if (!redondo) {
      opcoes.scales = { x: { grid: { display: false }, ticks: { autoSkip: true, maxRotation: 45 } }, y: { beginAtZero: true } };
      if (tipo === "bar" && extra.valores !== false) opcoes.layout = { padding: { top: 18 } };
    }
    estado.graficos.push(new Chart(canvas, { type: tipo, data: { labels, datasets }, options: opcoes }));
  }

  function tabela(corpo, colunas, linhas) {
    if (!linhas.length) { corpo.appendChild(el("div", "vazio", "Nenhum chamado.")); return; }
    const wrap = el("div", "tabela-wrap");
    const t = document.createElement("table");
    const thead = document.createElement("thead");
    const tr = document.createElement("tr");
    colunas.forEach((c, i) => { const th = el("th", i === 0 ? "num" : "", c); th.style.cursor = "default"; tr.appendChild(th); });
    thead.appendChild(tr);
    const tbody = document.createElement("tbody");
    linhas.forEach((l) => {
      const r = document.createElement("tr");
      l.forEach((c, i) => {
        const td = el("td", i === 0 || typeof c === "number" ? "num" : String(c).length > 40 ? "texto" : "", typeof c === "number" && i > 0 ? fmtNum(c) : String(c));
        if (c === "Expirado") td.style.color = "#c0392b";
        r.appendChild(td);
      });
      tbody.appendChild(r);
    });
    t.append(thead, tbody);
    wrap.appendChild(t);
    corpo.appendChild(wrap);
  }

  function iniciais(nome) {
    const partes = nome.trim().split(/\s+/).filter(Boolean);
    return ((partes[0] || "?")[0] + (partes.length > 1 ? partes[partes.length - 1][0] : "")).toUpperCase();
  }

  function cartaoKpi(nome, valor, media, corBorda, regra, sufixo = "", formato = null) {
    const c = el("div", "kpi-tec");
    c.style.setProperty("--kpi-cor", corBorda);
    c.appendChild(el("span", "nome", nome));
    const mostrar = (x) => (formato ? formato(x) : fmtNum(x));
    const v = el("span", "valor", valor === null || valor === undefined ? "–" : mostrar(valor));
    if (sufixo && valor !== null && valor !== undefined) v.appendChild(el("small", "", sufixo));
    c.appendChild(v);
    if (media !== null && media !== undefined) {
      let classe = "equipe";
      if (regra && valor !== null && valor !== undefined && valor !== media) {
        const melhor = regra === "maior" ? valor > media : valor < media;
        classe += melhor ? " melhor" : " pior";
      }
      c.appendChild(el("span", classe, `Média da equipe: ${mostrar(media)}${sufixo}`));
    }
    return c;
  }

  function renderizar(d, direcao) {
    estado.graficos.forEach((g) => g.destroy());
    estado.graficos = [];
    const slide = $("#slide");
    slide.innerHTML = "";
    const r = d.resumo, eq = d.equipe, t = d.tech;

    // perfil
    const perfil = el("section", "perfil");
    const foto = el("div", "foto");
    if (t.foto) {
      const img = document.createElement("img");
      img.src = `/api/tecnico/${t.id}/foto?v=${t.foto}`;
      img.alt = `Foto de ${t.name}`;
      foto.appendChild(img);
    } else {
      foto.appendChild(el("span", "iniciais", iniciais(t.name)));
    }
    perfil.appendChild(foto);
    perfil.appendChild(el("h2", "", t.name));
    perfil.appendChild(el("p", "periodo", `${dataBR($("#inicio").value)} a ${dataBR($("#fim").value)}`));
    if (!t.active) perfil.appendChild(el("p", "situacao", "Usuário inativo no GLPI"));
    if (ehAdmin()) {
      const acoes = el("div", "foto-acoes so-tela");
      const trocar = el("button", "", t.foto ? "Trocar foto" : "Adicionar foto");
      trocar.type = "button";
      trocar.addEventListener("click", () => $("#arquivo-foto").click());
      acoes.appendChild(trocar);
      if (t.foto) {
        const rem = el("button", "", "Remover foto");
        rem.type = "button";
        rem.addEventListener("click", removerFoto);
        acoes.appendChild(rem);
      }
      perfil.appendChild(acoes);
    }
    const sla = el("div", "destaque-sla");
    const vs = el("div", "valor", r.sla_pct === null ? "–" : `${fmtNum(r.sla_pct)}%`);
    sla.append(vs, el("div", "rotulo", "SLA cumprido no período"));
    if (eq.sla_pct !== null) sla.appendChild(el("div", "rotulo", `Média da equipe: ${fmtNum(eq.sla_pct)}%`));
    perfil.appendChild(sla);
    slide.appendChild(perfil);

    // indicadores
    const kpis = el("section", "kpis-tec");
    kpis.append(
      cartaoKpi("Abertos no período", r.abertos, eq.abertos, "#1f7a8c", null),
      cartaoKpi("Fechados no período", r.fechados, eq.fechados, "#2e8b57", "maior"),
      cartaoKpi("Em aberto agora", r.em_aberto, eq.em_aberto, "#12324a", "menor"),
      cartaoKpi("Pendentes", r.pendentes, eq.pendentes, "#d98e04", "menor"),
      cartaoKpi("Aguardando aprovação", r.aguardando, eq.aguardando, "#7d5ba6", null),
      cartaoKpi("Reabertos", r.reabertos, eq.reabertos, "#e07a5f", "menor"),
      cartaoKpi("SLA expirado (em aberto)", r.sla_expirado, eq.sla_expirado, "#c0392b", "menor"),
      cartaoKpi("Tempo médio de solução", r.tempo_medio || null, eq.tempo_medio, "#4f9fd1", "menor", " h"),
      cartaoKpi("Soma do tempo em pendência", r.pendencia_soma, eq.pendencia_soma, "#d98e04", "menor", "", fmtDur),
      cartaoKpi("Maior tempo em pendência", r.pendencia_maior, eq.pendencia_maior, "#c0392b", "menor", "", fmtDur),
    );
    slide.appendChild(kpis);

    // graficos
    const g1 = painel("span-4", "Chamados por status");
    slide.appendChild(g1.p);
    grafico(g1.corpo, "doughnut", d.status.labels, [{ label: "Chamados", data: d.status.datasets[0].data,
      backgroundColor: d.status.labels.map(cor), borderColor: "#fff", borderWidth: 2 }]);

    const g2 = painel("span-4", "Situação do SLA");
    slide.appendChild(g2.p);
    grafico(g2.corpo, "pie", d.sla.labels, [{ label: "Chamados", data: d.sla.datasets[0].data,
      backgroundColor: d.sla.labels.map(cor), borderColor: "#fff", borderWidth: 2 }]);

    const g3 = painel("span-4", "Comparação com a média da equipe");
    slide.appendChild(g3.p);
    const rotulos = ["Abertos", "Fechados", "Em aberto", "Pendentes", "Aguard. aprovação", "Reabertos"];
    const chaves = ["abertos", "fechados", "em_aberto", "pendentes", "aguardando", "reabertos"];
    grafico(g3.corpo, "bar", rotulos, [
      { label: t.name, data: chaves.map((k) => r[k]), backgroundColor: "#1f7a8c", borderRadius: 3 },
      { label: "Média da equipe", data: chaves.map((k) => eq[k] || 0), backgroundColor: "#9aa8b3", borderRadius: 3 },
    ]);

    const g4 = painel("span-12", "Abertos x Solucionados x Fechados");
    slide.appendChild(g4.p);
    grafico(g4.corpo, "line", d.evolucao.labels, d.evolucao.datasets.map((ds, i) => {
      const c = cor(ds.label, i);
      return { label: ds.label, data: ds.data, borderColor: c, backgroundColor: c, tension: 0.3, pointRadius: 2, borderWidth: 2 };
    }), { valores: false });

    // tabelas (no PDF saem completas, em paginas proprias)
    const t1 = painel("span-6 alto tabela-slide", "Chamados com SLA expirado");
    slide.appendChild(t1.p);
    const colsSla = d.sla_expirado.columns.filter((_, i) => i !== 2);
    tabela(t1.corpo, colsSla, d.sla_expirado.rows.map((l) => l.filter((_, i) => i !== 2)));
    const t2 = painel("span-6 alto tabela-slide", "Chamados em aberto");
    slide.appendChild(t2.p);
    tabela(t2.corpo, d.em_aberto.columns, d.em_aberto.rows);

    slide.classList.remove("entra-dir", "entra-esq");
    if (direcao) { void slide.offsetWidth; slide.classList.add(direcao > 0 ? "entra-dir" : "entra-esq"); }
  }

  // ------------------------------------------------------------ navegacao
  async function carregar(direcao = 0) {
    const tec = atual();
    if (!tec) return;
    $("#tecnico").value = String(tec.id);
    $("#posicao").textContent = `${estado.idx + 1} de ${estado.tecnicos.length} técnicos, em ordem alfabética`;
    salvarLocal("tec.id", tec.id);
    history.replaceState(null, "", `/tecnico?id=${tec.id}`);
    const ini = $("#inicio").value, fim = $("#fim").value;
    if (!ini || !fim || ini > fim) { aviso("Confira o período: a data inicial precisa ser anterior à final."); return; }
    try {
      const d = await api(`/api/tecnico/${tec.id}?${new URLSearchParams({ start: ini, end: fim })}`);
      estado.dados = d;
      tec.foto = d.tech.foto;
      $("#atualizado").textContent = d.loaded_at ? `Dados do GLPI de ${d.loaded_at}` : "";
      aviso(d.warning || "", "alerta");
      renderizar(d, direcao);
    } catch (e) {
      aviso(`Não foi possível carregar os dados: ${e.message}`);
    } finally {
      agendar();
    }
  }

  function navegar(passo) {
    const n = estado.tecnicos.length;
    if (!n) return;
    estado.idx = (estado.idx + passo + n) % n;
    carregar(passo);
  }

  function agendar() {
    clearTimeout(estado.timer);
    const prog = $("#progresso");
    if (!estado.tocando) { prog.hidden = true; return; }
    const seg = parseInt($("#intervalo").value, 10) || 20;
    prog.hidden = false;
    prog.style.setProperty("--duracao", `${seg}s`);
    prog.classList.remove("rodando");
    void prog.offsetWidth;
    prog.classList.add("rodando");
    estado.timer = setTimeout(() => navegar(1), seg * 1000);
  }

  function alternarApresentacao(ligar) {
    estado.tocando = ligar === undefined ? !estado.tocando : ligar;
    const b = $("#btn-play");
    b.textContent = estado.tocando ? "❚❚ Pausar" : "▶ Apresentação";
    b.classList.toggle("ativo", estado.tocando);
    agendar();
  }

  // ------------------------------------------------------------ foto
  function prepararImagem(arquivo) {
    return new Promise((ok, falha) => {
      if (!arquivo.type.startsWith("image/")) { falha(new Error("Escolha um arquivo de imagem.")); return; }
      if (arquivo.size > 15 * 1024 * 1024) { falha(new Error("A imagem passa de 15 MB.")); return; }
      const leitor = new FileReader();
      leitor.onerror = () => falha(new Error("Não foi possível ler o arquivo."));
      leitor.onload = () => {
        const img = new Image();
        img.onerror = () => falha(new Error("Formato de imagem não suportado."));
        img.onload = () => {
          // recorte quadrado central, 400 x 400 px
          const lado = Math.min(img.width, img.height);
          const c = document.createElement("canvas");
          c.width = 400; c.height = 400;
          c.getContext("2d").drawImage(img, (img.width - lado) / 2, (img.height - lado) / 2, lado, lado, 0, 0, 400, 400);
          ok(c.toDataURL("image/jpeg", 0.88));
        };
        img.src = leitor.result;
      };
      leitor.readAsDataURL(arquivo);
    });
  }

  async function enviarFoto(e) {
    const arquivo = e.target.files[0];
    e.target.value = "";
    if (!arquivo) return;
    try {
      const imagem = await prepararImagem(arquivo);
      await api(`/api/tecnico/${atual().id}/foto`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ image: imagem }) });
      toast("Foto salva.");
      carregar(0);
    } catch (err) { toast(`Não foi possível salvar a foto: ${err.message}`, 6000); }
  }

  async function removerFoto() {
    if (!confirm(`Remover a foto de ${atual().name}?`)) return;
    try {
      await api(`/api/tecnico/${atual().id}/foto`, { method: "DELETE" });
      toast("Foto removida.");
      carregar(0);
    } catch (err) { toast(err.message, 6000); }
  }

  // ------------------------------------------------------------ PDF do tecnico
  async function baixarPDF() {
    if (!estado.dados || !window.jspdf || !window.html2canvas) { toast("Ainda não há dados para exportar."); return; }
    toast("Gerando PDF…", 0);
    try {
      const { jsPDF } = window.jspdf;
      const doc = new jsPDF({ orientation: "landscape", unit: "mm", format: "a4" });
      const M = 10, PW = doc.internal.pageSize.getWidth(), PH = doc.internal.pageSize.getHeight(), UW = PW - 2 * M;
      const d = estado.dados;
      doc.setFont("helvetica", "bold"); doc.setFontSize(15); doc.setTextColor(18, 50, 74);
      doc.text(`Desempenho de ${d.tech.name}`, M, M + 5);
      doc.setFont("helvetica", "normal"); doc.setFontSize(9); doc.setTextColor(93, 111, 125);
      const agora = new Date().toLocaleString("pt-BR", { dateStyle: "short", timeStyle: "short" });
      doc.text(`Período: ${dataBR($("#inicio").value)} a ${dataBR($("#fim").value)}   |   Gerado em ${agora}` +
               (d.loaded_at ? `   |   Dados do GLPI de ${d.loaded_at}` : ""), M, M + 11);
      const y0 = M + 15;
      const canvas = await html2canvas($("#slide"), {
        scale: 2, backgroundColor: "#eef2f5", logging: false,
        onclone: (copia) => {
          const sl = copia.getElementById("slide");
          sl.classList.remove("entra-dir", "entra-esq");
          sl.style.animation = "none";
        },
        ignoreElements: (e) => !!(e.classList && (e.classList.contains("so-tela") || e.classList.contains("tabela-slide"))),
      });
      const proporcao = canvas.height / canvas.width;
      let larg = UW, alt = UW * proporcao;
      if (alt > PH - y0 - M) { alt = PH - y0 - M; larg = alt / proporcao; }
      doc.addImage(canvas.toDataURL("image/jpeg", 0.92), "JPEG", M + (UW - larg) / 2, y0, larg, alt);

      const tabelaPDF = (titulo, cols, linhas) => {
        doc.addPage();
        doc.setFont("helvetica", "bold"); doc.setFontSize(11); doc.setTextColor(29, 43, 54);
        doc.text(`${titulo} | ${d.tech.name}`, M, M + 4);
        doc.autoTable({
          head: [cols], body: linhas.length ? linhas.map((l) => l.map((c) => String(c))) : [["Nenhum chamado."]],
          startY: M + 7, margin: { left: M, right: M }, theme: "grid",
          styles: { font: "helvetica", fontSize: 8, cellPadding: 1.5, lineColor: [213, 222, 229], lineWidth: 0.1 },
          headStyles: { fillColor: [18, 50, 74], textColor: 255 }, alternateRowStyles: { fillColor: [244, 247, 249] },
        });
      };
      tabelaPDF("Chamados com SLA expirado", d.sla_expirado.columns.filter((_, i) => i !== 2), d.sla_expirado.rows.map((l) => l.filter((_, i) => i !== 2)));
      tabelaPDF("Chamados em aberto", d.em_aberto.columns, d.em_aberto.rows);

      const n = doc.getNumberOfPages();
      for (let i = 1; i <= n; i++) {
        doc.setPage(i); doc.setFont("helvetica", "normal"); doc.setFontSize(8); doc.setTextColor(93, 111, 125);
        doc.text(`Página ${i} de ${n}`, PW - M, PH - 4, { align: "right" });
      }
      doc.save(`desempenho_${slug(d.tech.name)}_${$("#inicio").value}_a_${$("#fim").value}.pdf`);
      toast("PDF gerado.");
    } catch (e) { toast(`Não foi possível gerar o PDF: ${e.message}`, 6000); }
  }

  // ------------------------------------------------------------ eventos e inicio
  function ligarEventos() {
    $("#anterior").addEventListener("click", () => navegar(-1));
    $("#proximo").addEventListener("click", () => navegar(1));
    $("#tecnico").addEventListener("change", (e) => {
      const novo = estado.tecnicos.findIndex((t) => String(t.id) === e.target.value);
      const dir = novo > estado.idx ? 1 : -1;
      estado.idx = novo;
      carregar(dir);
    });
    $("#periodo").addEventListener("change", (e) => {
      salvarLocal("tec.periodo", e.target.value);
      aplicarPreset(e.target.value);
      if (e.target.value !== "custom") carregar(0);
    });
    ["#inicio", "#fim"].forEach((s) => $(s).addEventListener("change", () => {
      $("#periodo").value = "custom";
      salvarLocal("tec.periodo", "custom");
      salvarLocal("tec.datas", [$("#inicio").value, $("#fim").value]);
      carregar(0);
    }));
    $("#btn-play").addEventListener("click", () => alternarApresentacao());
    $("#intervalo").addEventListener("change", () => { salvarLocal("tec.intervalo", $("#intervalo").value); agendar(); });
    $("#btn-pdf").addEventListener("click", baixarPDF);
    $("#arquivo-foto").addEventListener("change", enviarFoto);

    const telaCheia = () => {
      if (document.fullscreenElement) document.exitFullscreen();
      else if (document.documentElement.requestFullscreen) document.documentElement.requestFullscreen();
    };
    $("#btn-tela").addEventListener("click", telaCheia);
    document.addEventListener("fullscreenchange", () => {
      const ativo = !!document.fullscreenElement;
      document.body.classList.toggle("tela-cheia", ativo);
      $("#btn-tela").textContent = ativo ? "Sair da tela cheia" : "Tela cheia";
      estado.graficos.forEach((g) => g.resize());
    });

    document.addEventListener("keydown", (e) => {
      if (["INPUT", "SELECT", "TEXTAREA"].includes(document.activeElement.tagName)) return;
      if (e.key === "ArrowRight") { e.preventDefault(); navegar(1); }
      else if (e.key === "ArrowLeft") { e.preventDefault(); navegar(-1); }
      else if (e.key === " ") { e.preventDefault(); alternarApresentacao(); }
      else if (e.key === "f" || e.key === "F") telaCheia();
    });
  }

  async function iniciar() {
    if (!window.Chart) { aviso("A biblioteca de gráficos não foi carregada. Reconstrua a imagem Docker."); return; }
    ligarEventos();
    const preset = lerLocal("tec.periodo", "30");
    $("#periodo").value = preset;
    if (preset === "custom") {
      const [i, f] = lerLocal("tec.datas", ["", ""]);
      $("#inicio").value = i; $("#fim").value = f;
      if (!i || !f) { $("#periodo").value = "30"; aplicarPreset("30"); }
    } else aplicarPreset(preset);
    $("#intervalo").value = lerLocal("tec.intervalo", "20");

    try {
      estado.usuario = await api("/api/me");
      $("#slide").appendChild(el("div", "vazio span-12", "Carregando técnicos do GLPI…"));
      const r = await api("/api/tecnicos");
      const ativos = r.techs.filter((t) => t.active);
      estado.tecnicos = ativos.length ? ativos : r.techs;
      if (!estado.tecnicos.length) { $("#slide").innerHTML = ""; aviso("Nenhum técnico encontrado com o perfil configurado."); return; }
      const sel = $("#tecnico");
      estado.tecnicos.forEach((t) => sel.add(new Option(t.name, String(t.id))));
      const pedido = new URLSearchParams(location.search).get("id") || lerLocal("tec.id", null);
      const achado = estado.tecnicos.findIndex((t) => String(t.id) === String(pedido));
      estado.idx = achado >= 0 ? achado : 0;
      carregar(0);
    } catch (e) {
      $("#slide").innerHTML = "";
      aviso(`Não foi possível carregar os técnicos: ${e.message}`);
    }
  }

  iniciar();
})();
