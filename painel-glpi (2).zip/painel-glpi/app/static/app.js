/* Painel de Atendimento GLPI - interface */
(function () {
  "use strict";

  const $ = (s, el = document) => el.querySelector(s);

  // ------------------------------------------------------------ configuracoes visuais
  const PALETAS = {
    padrao:   { nome: "Padrão",            cores: ["#1f7a8c", "#12324a", "#d98e04", "#2e8b57", "#c0392b", "#7d5ba6", "#4f9fd1", "#a0522d", "#5d6f7d", "#e07a5f"] },
    azul:     { nome: "Tons de azul",      cores: ["#12324a", "#1d5a80", "#2b7bb0", "#4f9fd1", "#86bfe3", "#b9daf0", "#0e2233", "#3d6e8f", "#6aa3c8", "#a4c9e2"] },
    verde:    { nome: "Tons de verde",     cores: ["#2e8b57", "#1e5e3a", "#4caf7a", "#7fcf9f", "#b5e3c6", "#3f7d5a", "#a3c9a8", "#256d47", "#5fbf8a", "#d0efdc"] },
    quente:   { nome: "Quentes",           cores: ["#d98e04", "#e07a5f", "#c0392b", "#f2b134", "#a0522d", "#f4a261", "#8c2f1f", "#e9c46a", "#b5651d", "#ffd6a5"] },
    pastel:   { nome: "Pastel",            cores: ["#7d5ba6", "#8ecae6", "#a3c9a8", "#f4a3a8", "#ffd6a5", "#bdb2ff", "#caffbf", "#fdffb6", "#9bf6ff", "#ffc6ff"] },
    semaforo: { nome: "Por significado (status/SLA)", cores: ["#2e8b57", "#7fcf9f", "#d98e04", "#c0392b", "#9aa8b3", "#4f9fd1", "#7d5ba6", "#12324a", "#e07a5f", "#5d6f7d"] },
    alerta:   { nome: "Alerta",            cores: ["#c0392b", "#d98e04", "#8c2f1f", "#e07a5f", "#f2b134", "#a0522d", "#5d6f7d", "#12324a", "#7d5ba6", "#2e8b57"] },
    cinza:    { nome: "Neutro",            cores: ["#12324a", "#5d6f7d", "#9aa8b3", "#c9d3da", "#2c3e50", "#7f8c8d", "#b0bec5", "#455a64", "#90a4ae", "#cfd8dc"] },
  };

  // Cores fixas usadas pela paleta "Por significado": verde = ok, amarelo = atencao, vermelho = critico
  const SIGNIFICADO = {
    "No prazo": "#2e8b57", "Expirado": "#c0392b", "Solucionado no prazo": "#2e8b57",
    "Em aberto - no prazo": "#7fcf9f", "Solucionado fora do prazo": "#d98e04",
    "Em aberto - expirado": "#c0392b", "Sem SLA": "#9aa8b3",
    "Novo": "#4f9fd1", "Em atendimento": "#1f7a8c", "Planejado": "#7d5ba6", "Pendente": "#d98e04",
    "Pendentes": "#d98e04", "Aguardando aprovação": "#f2b134", "Fechado": "#2e8b57", "Fechados": "#2e8b57",
    "Em aberto": "#1f7a8c", "Abertos": "#1f7a8c", "Solucionados": "#7d5ba6", "Reabertos": "#c0392b",
    "Até 1 dia": "#2e8b57", "1 a 3 dias": "#7fcf9f", "3 a 7 dias": "#f2b134",
    "7 a 15 dias": "#d98e04", "15 a 30 dias": "#e07a5f", "Mais de 30 dias": "#c0392b",
  };

  const TIPOS = {
    series: [["pie", "Pizza"], ["doughnut", "Rosca"], ["polarArea", "Polar"], ["bar", "Barras verticais"],
             ["barh", "Barras horizontais"], ["line", "Linha"], ["area", "Área"], ["table", "Tabela"]],
    multi:  [["bar", "Barras agrupadas"], ["stacked", "Barras empilhadas"], ["barh", "Barras horizontais"],
             ["barh_stacked", "Barras horizontais empilhadas"], ["line", "Linhas"], ["area", "Áreas"],
             ["radar", "Radar"], ["table", "Tabela"]],
    kpi:    [["card", "Cartão com número"]],
    table:  [["table", "Tabela"]],
  };

  const ALTURAS = { P: 150, M: 330, G: 470 };

  const estado = {
    metricas: [], porId: {}, painel: { widgets: [] }, dados: null,
    tecnicos: [], selecionados: new Set(), editando: false, graficos: [], editandoId: null,
    usuario: null,
  };

  // ------------------------------------------------------------ utilitarios
  async function api(url, opcoes) {
    const r = await fetch(url, opcoes);
    if (r.status === 401) {
      window.location.href = "/login";
      throw new Error("Sessão expirada.");
    }
    let j = null;
    try { j = await r.json(); } catch (e) { /* sem corpo */ }
    if (!r.ok) throw new Error((j && (j.detail || j.message)) || `Erro HTTP ${r.status}`);
    return j;
  }
  const enviar = (metodo, url, corpo) => api(url, { method: metodo, headers: { "Content-Type": "application/json" }, body: JSON.stringify(corpo || {}) });
  const post = (url, corpo) => enviar("POST", url, corpo);

  let tempoToast = null;
  function toast(msg, ms = 3500) {
    const el = $("#toast");
    el.textContent = msg;
    el.hidden = false;
    clearTimeout(tempoToast);
    if (ms) tempoToast = setTimeout(() => { el.hidden = true; }, ms);
  }

  function fecharMenus(excecao) {
    document.querySelectorAll(".menu").forEach((m) => { if (m !== excecao) m.hidden = true; });
    if (excecao !== $("#lista-tecnicos")) $("#lista-tecnicos").hidden = true;
  }

  const ehAdmin = () => estado.usuario && estado.usuario.role === "admin";

  const fmtNum = (v) => (typeof v === "number" ? v.toLocaleString("pt-BR") : v);
  const iso = (d) => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
  const novoId = () => Math.random().toString(16).slice(2, 10);
  const salvarLocal = (k, v) => { try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) { /* ignora */ } };
  const lerLocal = (k, p) => { try { const v = localStorage.getItem(k); return v ? JSON.parse(v) : p; } catch (e) { return p; } };

  function hexA(hex, a) {
    const n = parseInt(hex.slice(1), 16);
    return `rgba(${(n >> 16) & 255}, ${(n >> 8) & 255}, ${n & 255}, ${a})`;
  }

  function aviso(msg, tipo) {
    const el = $("#aviso");
    el.hidden = !msg;
    el.textContent = msg || "";
    el.classList.toggle("alerta", tipo === "alerta");
  }

  // ------------------------------------------------------------ periodo
  function aplicarPreset(p) {
    const hoje = new Date();
    let ini = new Date(hoje), fim = new Date(hoje);
    if (p === "hoje") { /* mesmo dia */ }
    else if (p === "mes") ini = new Date(hoje.getFullYear(), hoje.getMonth(), 1);
    else if (p === "mes_ant") { ini = new Date(hoje.getFullYear(), hoje.getMonth() - 1, 1); fim = new Date(hoje.getFullYear(), hoje.getMonth(), 0); }
    else if (p === "ano") ini = new Date(hoje.getFullYear(), 0, 1);
    else if (p === "custom") return;
    else ini.setDate(hoje.getDate() - (parseInt(p, 10) - 1));
    $("#inicio").value = iso(ini);
    $("#fim").value = iso(fim);
  }

  // ------------------------------------------------------------ plugin: valores no grafico
  const pluginValores = {
    id: "valores",
    afterDatasetsDraw(chart, args, opts) {
      if (!opts || !opts.enabled) return;
      const { ctx } = chart;
      const redondo = ["pie", "doughnut", "polarArea"].includes(chart.config.type);
      const horizontal = chart.options.indexAxis === "y";
      ctx.save();
      ctx.font = "600 11px 'Segoe UI', system-ui, sans-serif";
      ctx.textBaseline = "middle";
      chart.data.datasets.forEach((ds, i) => {
        const meta = chart.getDatasetMeta(i);
        if (meta.hidden) return;
        meta.data.forEach((el, j) => {
          const v = ds.data[j];
          if (v === null || v === undefined || v === 0 || !chart.getDataVisibility(j)) return;
          const p = el.tooltipPosition();
          let x = p.x, y = p.y;
          ctx.textAlign = "center";
          ctx.fillStyle = redondo ? "#ffffff" : "#1d2b36";
          if (!redondo) {
            if (chart.config.type === "bar" && horizontal) { ctx.textAlign = "left"; x += 4; }
            else y -= 9;
          }
          ctx.fillText(fmtNum(v), x, y);
        });
      });
      ctx.restore();
    },
  };
  if (window.Chart) Chart.register(pluginValores);

  // ------------------------------------------------------------ renderizacao
  function destruirGraficos() {
    estado.graficos.forEach((g) => g.destroy());
    estado.graficos = [];
  }

  function renderizar() {
    destruirGraficos();
    const grade = $("#grade");
    grade.innerHTML = "";
    grade.classList.toggle("editando", estado.editando);
    if (!estado.painel.widgets.length) {
      grade.innerHTML = '<div class="w-12 vazio" style="padding:60px">O painel está vazio. Clique em "Editar painel" e depois em "Adicionar gráfico".</div>';
      return;
    }
    estado.painel.widgets.forEach((w, idx) => grade.appendChild(criarPainel(w, idx)));
  }

  function criarPainel(w, idx) {
    const meta = estado.porId[w.metric];
    const el = document.createElement("section");
    el.className = `painel w-${w.width}`;
    el.dataset.id = w.id;
    el.style.height = `${ALTURAS[w.height] || ALTURAS.M}px`;

    const topo = document.createElement("div");
    topo.className = "painel-topo";
    const titulo = document.createElement("h3");
    titulo.className = "painel-titulo";
    titulo.textContent = w.title;
    if (meta) titulo.title = meta.help;
    topo.appendChild(titulo);

    const acoesPainel = document.createElement("div");
    acoesPainel.className = "painel-acoes";
    const dd = document.createElement("div");
    dd.className = "dropdown";
    const be = document.createElement("button");
    be.type = "button"; be.className = "btn-exportar"; be.textContent = "⤓";
    be.title = "Baixar este gráfico"; be.setAttribute("aria-label", "Baixar este gráfico");
    const menu = document.createElement("div");
    menu.className = "menu"; menu.hidden = true;
    [["Baixar CSV", () => exportarCSVWidget(w)], ["Baixar PDF", () => exportarPDF([w], nomeArquivo(w.title, "pdf"))]]
      .forEach(([txt, fn]) => {
        const b = document.createElement("button");
        b.type = "button"; b.textContent = txt;
        b.addEventListener("click", () => { menu.hidden = true; fn(); });
        menu.appendChild(b);
      });
    be.addEventListener("click", (e) => { e.stopPropagation(); fecharMenus(menu); menu.hidden = !menu.hidden; });
    dd.append(be, menu);
    acoesPainel.appendChild(dd);
    topo.appendChild(acoesPainel);

    if (estado.editando) {
      const f = document.createElement("div");
      f.className = "ferramentas";
      [["←", "Mover para trás", () => mover(idx, -1)], ["→", "Mover para frente", () => mover(idx, 1)],
       ["✎", "Editar gráfico", () => abrirEditor(w.id)], ["✕", "Remover gráfico", () => remover(idx)]]
        .forEach(([txt, dica, fn]) => {
          const b = document.createElement("button");
          b.type = "button"; b.textContent = txt; b.title = dica; b.setAttribute("aria-label", dica);
          b.addEventListener("click", fn);
          f.appendChild(b);
        });
      acoesPainel.appendChild(f);
    }
    el.appendChild(topo);

    const corpo = document.createElement("div");
    corpo.className = "painel-corpo";
    el.appendChild(corpo);

    const d = estado.dados && estado.dados.metrics ? estado.dados.metrics[w.metric] : null;
    if (!meta) { corpo.innerHTML = '<div class="vazio">Métrica não encontrada. Edite este gráfico.</div>'; return el; }
    if (!d) { corpo.innerHTML = `<div class="vazio">${estado.dados ? "Sem dados." : "Aguardando dados…"}</div>`; return el; }

    if (meta.kind === "kpi") desenharKpi(el, corpo, w, d);
    else if (meta.kind === "table") desenharTabela(corpo, d.columns, d.rows);
    else if (!d.labels.length || d.datasets.every((ds) => ds.data.every((v) => !v))) corpo.innerHTML = '<div class="vazio">Nenhum chamado para os filtros selecionados.</div>';
    else if (w.type === "table") desenharTabela(corpo, [""].concat(d.datasets.map((x) => x.label)), d.labels.map((l, i) => [l].concat(d.datasets.map((x) => x.data[i]))));
    else desenharGrafico(corpo, w, d, meta.kind);
    return el;
  }

  function desenharKpi(painel, corpo, w, d) {
    painel.classList.add("kpi");
    const cor = (PALETAS[w.palette] || PALETAS.padrao).cores[0];
    painel.style.setProperty("--kpi-cor", cor);
    const v = document.createElement("div");
    v.className = "kpi-valor";
    v.textContent = d.text ? d.text : d.value === null || d.value === undefined ? "–" : fmtNum(d.value);
    if (!d.text && d.suffix && d.value !== null && d.value !== undefined) {
      const s = document.createElement("span");
      s.className = "kpi-sufixo"; s.textContent = d.suffix.trim();
      v.appendChild(s);
    }
    corpo.appendChild(v);
  }

  function desenharTabela(corpo, colunas, linhas) {
    if (!linhas.length) { corpo.innerHTML = '<div class="vazio">Nenhum registro.</div>'; return; }
    const wrap = document.createElement("div");
    wrap.className = "tabela-wrap";
    const tabela = document.createElement("table");
    const numerica = colunas.map((_, i) => linhas.every((l) => typeof l[i] === "number" || /^-?[\d.,]+%?$/.test(String(l[i]))));
    const thead = document.createElement("thead");
    const trh = document.createElement("tr");
    let ordemCol = -1, asc = true;
    const tbody = document.createElement("tbody");

    function preencher(dados) {
      tbody.innerHTML = "";
      dados.forEach((l) => {
        const tr = document.createElement("tr");
        l.forEach((c, i) => {
          const td = document.createElement("td");
          td.textContent = typeof c === "number" ? fmtNum(c) : c;
          if (numerica[i]) td.className = "num";
          else if (String(c).length > 40) td.className = "texto";
          tr.appendChild(td);
        });
        tbody.appendChild(tr);
      });
    }
    const valor = (x) => { const n = parseFloat(String(x).replace("%", "")); return isNaN(n) ? String(x).toLowerCase() : n; };

    colunas.forEach((c, i) => {
      const th = document.createElement("th");
      th.textContent = c;
      th.title = "Clique para ordenar";
      if (numerica[i]) th.className = "num";
      th.addEventListener("click", () => {
        asc = ordemCol === i ? !asc : true;
        ordemCol = i;
        preencher(linhas.slice().sort((a, b) => {
          const x = valor(a[i]), y = valor(b[i]);
          return (x > y ? 1 : x < y ? -1 : 0) * (asc ? 1 : -1);
        }));
      });
      trh.appendChild(th);
    });
    thead.appendChild(trh);
    tabela.append(thead, tbody);
    preencher(linhas);
    wrap.appendChild(tabela);
    corpo.appendChild(wrap);
  }

  function desenharGrafico(corpo, w, d, kind) {
    const canvas = document.createElement("canvas");
    corpo.appendChild(canvas);
    const cores = (PALETAS[w.palette] || PALETAS.padrao).cores;
    const porSignificado = w.palette === "semaforo";
    const cor = (rotulo, i) => (porSignificado && SIGNIFICADO[rotulo]) || cores[i % cores.length];
    let tipo = w.type, eixo = "x", empilhado = false, preencher = false;
    if (tipo === "barh") { tipo = "bar"; eixo = "y"; }
    if (tipo === "stacked") { tipo = "bar"; empilhado = true; }
    if (tipo === "barh_stacked") { tipo = "bar"; eixo = "y"; empilhado = true; }
    if (tipo === "area") { tipo = "line"; preencher = true; }
    const redondo = ["pie", "doughnut", "polarArea"].includes(tipo);
    const coresPorItem = redondo || (kind === "series" && tipo === "bar");

    const datasets = d.datasets.map((ds, i) => {
      const base = { label: ds.label, data: ds.data };
      if (coresPorItem) {
        const c = d.labels.map((l, j) => cor(l, j));
        return { ...base, backgroundColor: redondo && tipo === "polarArea" ? c.map((x) => hexA(x, 0.75)) : c,
                 borderColor: redondo ? "#ffffff" : c, borderWidth: redondo ? 2 : 0, borderRadius: redondo ? 0 : 3 };
      }
      const c = cor(ds.label, i);
      if (tipo === "line") return { ...base, borderColor: c, backgroundColor: preencher ? hexA(c, 0.22) : c, fill: preencher, tension: 0.3, pointRadius: 2, borderWidth: 2 };
      if (tipo === "radar") return { ...base, borderColor: c, backgroundColor: hexA(c, 0.2), pointBackgroundColor: c };
      return { ...base, backgroundColor: c, borderRadius: 3 };
    });

    const mostrarLegenda = !!w.legend && (redondo || datasets.length > 1);
    const opcoes = {
      responsive: true, maintainAspectRatio: false, indexAxis: eixo, animation: { duration: 300 },
      plugins: {
        legend: { display: mostrarLegenda, position: redondo ? "right" : "bottom", labels: { boxWidth: 12, usePointStyle: true } },
        valores: { enabled: !!w.values },
        tooltip: { callbacks: { label: (c) => ` ${c.dataset.label === "Chamados" && redondo ? c.label : c.dataset.label}: ${fmtNum(c.raw)}` } },
      },
    };
    if (w.values && !redondo) opcoes.layout = { padding: eixo === "y" ? { right: 36 } : { top: 18 } };
    if (!redondo && tipo !== "radar") {
      opcoes.scales = {
        x: { stacked: empilhado, beginAtZero: true, grid: { display: eixo === "y" }, ticks: { autoSkip: true, maxRotation: 45 } },
        y: { stacked: empilhado, beginAtZero: true, grid: { display: eixo !== "y" } },
      };
    }
    if (tipo === "radar") opcoes.scales = { r: { beginAtZero: true } };
    estado.graficos.push(new Chart(canvas, { type: tipo, data: { labels: d.labels, datasets }, options: opcoes }));
  }

  // ------------------------------------------------------------ dados
  function filtros() {
    const ini = $("#inicio").value, fim = $("#fim").value;
    const tecnicos = estado.selecionados.size && estado.selecionados.size < estado.tecnicos.length ? [...estado.selecionados].join(",") : "";
    return { ini, fim, q: new URLSearchParams({ start: ini, end: fim, techs: tecnicos }) };
  }

  let temporizador = null;
  async function carregarDados(atualizar = false) {
    const { ini, fim, q } = filtros();
    if (!ini || !fim) return;
    if (ini > fim) { aviso("A data inicial é maior que a data final."); return; }
    if (atualizar) q.set("refresh", "true");
    $("#carregando").hidden = false;
    try {
      const d = await api(`/api/data?${q}`);
      estado.dados = d;
      atualizarTecnicos(d.techs);
      $("#atualizado").textContent = d.loaded_at ? `Dados do GLPI de ${d.loaded_at}` : "";
      aviso(d.warning || "", "alerta");
    } catch (e) {
      aviso(`Não foi possível carregar os dados: ${e.message} Confira a conexão em Configurações.`);
    } finally {
      $("#carregando").hidden = true;
    }
    renderizar();
  }
  const recarregar = () => { clearTimeout(temporizador); temporizador = setTimeout(() => carregarDados(false), 250); };

  // ------------------------------------------------------------ filtro de tecnicos
  function atualizarTecnicos(lista) {
    const primeiraVez = !estado.tecnicos.length;
    estado.tecnicos = lista;
    if (primeiraVez) {
      const salvos = lerLocal("painel.tecnicos", null);
      estado.selecionados = new Set(salvos ? salvos.filter((id) => lista.some((t) => t.id === id)) : lista.map((t) => t.id));
      if (!estado.selecionados.size) estado.selecionados = new Set(lista.map((t) => t.id));
    }
    desenharListaTecnicos();
  }

  function desenharListaTecnicos() {
    const busca = $("#tec-busca").value.trim().toLowerCase();
    const box = $("#tec-itens");
    box.innerHTML = "";
    estado.tecnicos.filter((t) => t.name.toLowerCase().includes(busca)).forEach((t) => {
      const l = document.createElement("label");
      if (!t.active) l.className = "inativo";
      const c = document.createElement("input");
      c.type = "checkbox"; c.checked = estado.selecionados.has(t.id);
      c.addEventListener("change", () => {
        c.checked ? estado.selecionados.add(t.id) : estado.selecionados.delete(t.id);
        mudouTecnicos();
      });
      l.append(c, document.createTextNode(t.name + (t.active ? "" : " (inativo)")));
      box.appendChild(l);
    });
    const n = estado.selecionados.size, total = estado.tecnicos.length;
    $("#btn-tecnicos").textContent = !total || n === total ? "Técnicos: todos" : `Técnicos: ${n} de ${total}`;
  }

  function mudouTecnicos() {
    if (!estado.selecionados.size) estado.selecionados = new Set(estado.tecnicos.map((t) => t.id));
    salvarLocal("painel.tecnicos", [...estado.selecionados]);
    desenharListaTecnicos();
    recarregar();
  }

  // ------------------------------------------------------------ edicao do painel
  async function salvarPainel() {
    try { await post("/api/dashboard", estado.painel); }
    catch (e) { aviso(`Não foi possível salvar o painel: ${e.message}`); }
  }
  function mover(idx, delta) {
    const ws = estado.painel.widgets, alvo = idx + delta;
    if (alvo < 0 || alvo >= ws.length) return;
    [ws[idx], ws[alvo]] = [ws[alvo], ws[idx]];
    salvarPainel(); renderizar();
  }
  function remover(idx) {
    if (!confirm(`Remover o gráfico "${estado.painel.widgets[idx].title}"?`)) return;
    estado.painel.widgets.splice(idx, 1);
    salvarPainel(); renderizar();
  }

  function preencherTipos(kind, atual) {
    const sel = $("#w-tipo");
    sel.innerHTML = "";
    (TIPOS[kind] || TIPOS.series).forEach(([v, n]) => sel.add(new Option(n, v)));
    sel.value = (TIPOS[kind] || []).some(([v]) => v === atual) ? atual : sel.options[0].value;
    const grafico = kind === "series" || kind === "multi";
    $("#w-legenda").disabled = !grafico;
    $("#w-valores").disabled = !grafico;
  }

  function abrirEditor(id) {
    estado.editandoId = id || null;
    const w = id ? estado.painel.widgets.find((x) => x.id === id) : null;
    $("#dlg-widget-titulo").textContent = w ? "Editar gráfico" : "Adicionar gráfico";
    const metrica = w ? w.metric : estado.metricas[0].id;
    $("#w-metrica").value = metrica;
    const meta = estado.porId[metrica];
    $("#w-titulo").value = w ? w.title : meta.title;
    $("#w-ajuda").textContent = meta.help;
    preencherTipos(meta.kind, w ? w.type : null);
    $("#w-paleta").value = w ? w.palette : "padrao";
    $("#w-largura").value = String(w ? w.width : meta.kind === "kpi" ? 3 : 6);
    $("#w-altura").value = w ? w.height : meta.kind === "kpi" ? "P" : "M";
    $("#w-legenda").checked = w ? !!w.legend : true;
    $("#w-valores").checked = w ? !!w.values : false;
    $("#dlg-widget").showModal();
  }

  function salvarEditor() {
    const meta = estado.porId[$("#w-metrica").value];
    const dados = {
      metric: meta.id, title: $("#w-titulo").value.trim() || meta.title, type: $("#w-tipo").value,
      palette: $("#w-paleta").value, width: parseInt($("#w-largura").value, 10), height: $("#w-altura").value,
      legend: $("#w-legenda").checked, values: $("#w-valores").checked,
    };
    if (estado.editandoId) Object.assign(estado.painel.widgets.find((x) => x.id === estado.editandoId), dados);
    else estado.painel.widgets.push({ id: novoId(), ...dados });
    salvarPainel(); renderizar();
  }

  function modoEdicao(ativo) {
    estado.editando = ativo;
    $("#barra-edicao").hidden = !ativo;
    $("#btn-editar").hidden = ativo;
    renderizar();
  }

  // ------------------------------------------------------------ configuracoes
  async function abrirConfig(intro) {
    const c = await api("/api/config");
    $("#cfg-intro").textContent = intro || "Os tokens ficam gravados somente no servidor do painel. Deixe um token em branco para manter o valor já salvo.";
    $("#c-url").value = c.glpi_url || "";
    $("#c-app").value = ""; $("#c-user").value = "";
    $("#c-app").placeholder = c.app_token_set ? "•••••• (salvo; preencha só para trocar)" : "Configurar > Geral > API > Cliente da API";
    $("#c-user").placeholder = c.user_token_set ? "•••••• (salvo; preencha só para trocar)" : "Minhas configurações > Token da API";
    $("#c-app-limpar").checked = false;
    $("#c-perfil").value = c.tech_profile || "Technician";
    $("#c-cache").value = c.cache_minutes || 10;
    $("#c-timeout").value = c.timeout || 90;
    $("#c-tentativas").value = c.retries || 3;
    $("#c-ssl").checked = !!c.verify_ssl;
    $("#c-resultado").hidden = true;
    $("#dlg-config").showModal();
  }

  function lerFormConfig() {
    return {
      glpi_url: $("#c-url").value.trim(), app_token: $("#c-app").value.trim(), user_token: $("#c-user").value.trim(),
      clear_app_token: $("#c-app-limpar").checked, tech_profile: $("#c-perfil").value.trim() || "Technician",
      cache_minutes: parseInt($("#c-cache").value, 10) || 10, verify_ssl: $("#c-ssl").checked,
      timeout: parseInt($("#c-timeout").value, 10) || 90, retries: parseInt($("#c-tentativas").value, 10) || 3,
    };
  }

  function resultado(ok, msg) {
    const el = $("#c-resultado");
    el.hidden = false;
    el.className = `resultado ${ok ? "ok" : "erro"}`;
    el.textContent = msg;
  }

  // ------------------------------------------------------------ exportacao
  function nomeArquivo(titulo, ext) {
    const base = titulo.normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase()
      .replace(/[^a-z0-9]+/g, "_").replace(/^_+|_+$/g, "") || "painel";
    const { ini, fim } = filtros();
    return `${base}_${ini}_a_${fim}.${ext}`;
  }

  function baixarArquivo(nome, blob) {
    const a = document.createElement("a");
    a.href = URL.createObjectURL(blob);
    a.download = nome;
    document.body.appendChild(a);
    a.click();
    setTimeout(() => { URL.revokeObjectURL(a.href); a.remove(); }, 1500);
  }

  function celulaCSV(v) {
    if (v === null || v === undefined) return "";
    let s = typeof v === "number" ? String(v).replace(".", ",") : String(v);
    if (/[";\r\n]/.test(s)) s = `"${s.replace(/"/g, '""')}"`;
    return s;
  }

  function baixarCSV(nome, colunas, linhas) {
    const texto = [colunas].concat(linhas).map((l) => l.map(celulaCSV).join(";")).join("\r\n");
    baixarArquivo(nome, new Blob(["\ufeff" + texto], { type: "text/csv;charset=utf-8" }));
  }

  function dadosTabulares(w) {
    const meta = estado.porId[w.metric];
    const d = estado.dados && estado.dados.metrics ? estado.dados.metrics[w.metric] : null;
    if (!meta || !d) return { cols: [w.title], rows: [] };
    if (meta.kind === "kpi") {
      return { cols: ["Indicador", "Valor", "Unidade"],
               rows: [[w.title, d.value === null || d.value === undefined ? "" : d.value, (d.suffix || "").trim()]] };
    }
    if (meta.kind === "table") return { cols: d.columns, rows: d.rows };
    const primeira = meta.group === "Por técnico" ? "Técnico" : w.metric === "evolucao" ? "Data" : "Item";
    return { cols: [primeira].concat(d.datasets.map((x) => x.label)),
             rows: d.labels.map((l, i) => [l].concat(d.datasets.map((x) => x.data[i]))) };
  }

  function exportarCSVWidget(w) {
    if (!estado.dados) { toast("Ainda não há dados carregados."); return; }
    const { cols, rows } = dadosTabulares(w);
    baixarCSV(nomeArquivo(w.title, "csv"), cols, rows);
  }

  async function exportarCSVChamados() {
    toast("Gerando CSV dos chamados…", 0);
    try {
      const r = await fetch(`/api/export/chamados.csv?${filtros().q}`);
      if (r.status === 401) { window.location.href = "/login"; return; }
      if (!r.ok) { const j = await r.json().catch(() => ({})); throw new Error(j.detail || `HTTP ${r.status}`); }
      baixarArquivo(nomeArquivo("chamados", "csv"), await r.blob());
      toast("CSV dos chamados gerado.");
    } catch (e) {
      toast(`Não foi possível gerar o CSV: ${e.message}`, 6000);
    }
  }

  const dataBR = (isoData) => (isoData ? isoData.split("-").reverse().join("/") : "");
  function textoTecnicos() {
    const total = estado.tecnicos.length, n = estado.selecionados.size;
    if (!total || n === total) return "todos";
    return estado.tecnicos.filter((t) => estado.selecionados.has(t.id)).map((t) => t.name).join(", ");
  }

  async function exportarPDF(widgets, nome) {
    if (!window.jspdf || !window.html2canvas) { toast("As bibliotecas de PDF não foram carregadas."); return; }
    if (!estado.dados) { toast("Ainda não há dados carregados."); return; }
    toast("Gerando PDF…", 0);
    try {
      const { jsPDF } = window.jspdf;
      const doc = new jsPDF({ orientation: "landscape", unit: "mm", format: "a4" });
      const M = 10, G = 4;
      const PW = doc.internal.pageSize.getWidth(), PH = doc.internal.pageSize.getHeight(), UW = PW - 2 * M;
      const { ini, fim } = filtros();

      doc.setFont("helvetica", "bold"); doc.setFontSize(15); doc.setTextColor(18, 50, 74);
      doc.text("Painel de Atendimento GLPI", M, M + 5);
      doc.setFont("helvetica", "normal"); doc.setFontSize(9); doc.setTextColor(93, 111, 125);
      const info = doc.splitTextToSize(`Período: ${dataBR(ini)} a ${dataBR(fim)}   |   Técnicos: ${textoTecnicos()}`, UW);
      doc.text(info, M, M + 11);
      let y = M + 11 + info.length * 4;
      const agora = new Date().toLocaleString("pt-BR", { dateStyle: "short", timeStyle: "short" });
      doc.text(`Gerado em ${agora} por ${estado.usuario ? estado.usuario.name : ""}` +
               (estado.dados.loaded_at ? `   |   Dados do GLPI de ${estado.dados.loaded_at}` : ""), M, y);
      y += 6;

      let x = 0, alturaLinha = 0;
      const quebrarLinha = () => { if (x > 0) { y += alturaLinha + G; x = 0; alturaLinha = 0; } };

      for (const w of widgets) {
        const meta = estado.porId[w.metric];
        const ehTabela = meta && (meta.kind === "table" || w.type === "table");
        if (ehTabela) {
          quebrarLinha();
          if (y > PH - M - 25) { doc.addPage(); y = M; }
          const { cols, rows } = dadosTabulares(w);
          doc.setFont("helvetica", "bold"); doc.setFontSize(10); doc.setTextColor(29, 43, 54);
          doc.text(w.title, M, y + 4);
          doc.autoTable({
            head: [cols],
            body: rows.map((r) => r.map((v) => (typeof v === "number" ? fmtNum(v) : v === null || v === undefined ? "" : String(v)))),
            startY: y + 6, margin: { left: M, right: M }, theme: "grid",
            styles: { font: "helvetica", fontSize: 7.5, cellPadding: 1.4, overflow: "linebreak", lineColor: [213, 222, 229], lineWidth: 0.1 },
            headStyles: { fillColor: [18, 50, 74], textColor: 255, fontStyle: "bold" },
            alternateRowStyles: { fillColor: [244, 247, 249] },
          });
          y = doc.lastAutoTable.finalY + G + 2;
          continue;
        }
        const el = document.querySelector(`.painel[data-id="${w.id}"]`);
        if (!el) continue;
        const canvas = await html2canvas(el, {
          scale: 2, backgroundColor: "#ffffff", logging: false,
          ignoreElements: (e) => !!(e.classList && e.classList.contains("painel-acoes")),
        });
        const larg = (UW + G) * (w.width / 12) - G;
        const alt = (canvas.height * larg) / canvas.width;
        if (x + larg > UW + 0.5) quebrarLinha();
        if (y + alt > PH - M) { doc.addPage(); y = M; x = 0; alturaLinha = 0; }
        doc.addImage(canvas.toDataURL("image/jpeg", 0.92), "JPEG", M + x, y, larg, alt);
        x += larg + G;
        alturaLinha = Math.max(alturaLinha, alt);
      }

      const paginas = doc.getNumberOfPages();
      for (let i = 1; i <= paginas; i++) {
        doc.setPage(i);
        doc.setFont("helvetica", "normal"); doc.setFontSize(8); doc.setTextColor(93, 111, 125);
        doc.text(`Página ${i} de ${paginas}`, PW - M, PH - 4, { align: "right" });
      }
      doc.save(nome);
      toast("PDF gerado.");
    } catch (e) {
      toast(`Não foi possível gerar o PDF: ${e.message}`, 6000);
    }
  }

  // ------------------------------------------------------------ usuarios do painel
  let usuarioEditando = null;

  async function abrirUsuarios() {
    $("#u-resultado").hidden = true;
    limparFormUsuario();
    await listarUsuarios();
    $("#dlg-usuarios").showModal();
  }

  function msgUsuario(ok, texto) {
    const el = $("#u-resultado");
    el.hidden = false;
    el.className = `resultado ${ok ? "ok" : "erro"}`;
    el.textContent = texto;
  }

  async function listarUsuarios() {
    const r = await api("/api/users");
    const tb = $("#u-lista");
    tb.innerHTML = "";
    r.users.forEach((u) => {
      const tr = document.createElement("tr");
      [u.username, u.name, u.role_label, u.created].forEach((v, i) => {
        const td = document.createElement("td");
        td.textContent = v;
        if (i === 0 && u.username === estado.usuario.username) {
          const s = document.createElement("span"); s.className = "voce"; s.textContent = "(você)"; td.appendChild(s);
        }
        tr.appendChild(td);
      });
      const td = document.createElement("td");
      const be = document.createElement("button");
      be.type = "button"; be.className = "link"; be.textContent = "Editar";
      be.addEventListener("click", () => editarUsuario(u));
      td.appendChild(be);
      if (u.username !== estado.usuario.username) {
        const br = document.createElement("button");
        br.type = "button"; br.className = "link perigo"; br.textContent = "Remover";
        br.addEventListener("click", async () => {
          if (!confirm(`Remover o usuário "${u.username}"?`)) return;
          try {
            await enviar("DELETE", `/api/users/${encodeURIComponent(u.username)}`);
            msgUsuario(true, `Usuário "${u.username}" removido.`);
            limparFormUsuario();
            listarUsuarios();
          } catch (e) { msgUsuario(false, e.message); }
        });
        td.appendChild(br);
      }
      tr.appendChild(td);
      tb.appendChild(tr);
    });
  }

  function limparFormUsuario() {
    usuarioEditando = null;
    $("#u-form-titulo").textContent = "Novo usuário";
    $("#u-login").value = ""; $("#u-login").disabled = false;
    $("#u-nome").value = ""; $("#u-perfil").value = "admin";
    $("#u-senha").value = ""; $("#u-senha").required = true;
    $("#u-senha-ajuda").textContent = "Mínimo de 8 caracteres.";
    $("#u-salvar").textContent = "Cadastrar usuário";
    $("#u-novo").hidden = true;
  }

  function editarUsuario(u) {
    usuarioEditando = u.username;
    $("#u-form-titulo").textContent = `Editar usuário ${u.username}`;
    $("#u-login").value = u.username; $("#u-login").disabled = true;
    $("#u-nome").value = u.name; $("#u-perfil").value = u.role;
    $("#u-senha").value = ""; $("#u-senha").required = false;
    $("#u-senha-ajuda").textContent = "Deixe a senha em branco para manter a atual.";
    $("#u-salvar").textContent = "Salvar alterações";
    $("#u-novo").hidden = false;
    $("#u-resultado").hidden = true;
  }

  async function salvarUsuario(e) {
    e.preventDefault();
    const corpo = { name: $("#u-nome").value.trim(), role: $("#u-perfil").value, password: $("#u-senha").value };
    try {
      if (usuarioEditando) {
        await enviar("PUT", `/api/users/${encodeURIComponent(usuarioEditando)}`, corpo);
        msgUsuario(true, `Usuário "${usuarioEditando}" atualizado.`);
        if (usuarioEditando === estado.usuario.username) {
          estado.usuario = await api("/api/me");
          aplicarUsuario();
        }
      } else {
        corpo.username = $("#u-login").value.trim();
        await post("/api/users", corpo);
        msgUsuario(true, `Usuário "${corpo.username}" cadastrado.`);
      }
      limparFormUsuario();
      listarUsuarios();
    } catch (err) { msgUsuario(false, err.message); }
  }

  function abrirSenha() {
    ["#s-atual", "#s-nova", "#s-repete"].forEach((s) => { $(s).value = ""; });
    $("#s-resultado").hidden = true;
    $("#dlg-senha").showModal();
  }

  async function salvarSenha(e) {
    e.preventDefault();
    const el = $("#s-resultado");
    const mostrar = (ok, t) => { el.hidden = false; el.className = `resultado ${ok ? "ok" : "erro"}`; el.textContent = t; };
    if ($("#s-nova").value !== $("#s-repete").value) { mostrar(false, "A nova senha e a repetição não são iguais."); return; }
    try {
      await post("/api/me/password", { current: $("#s-atual").value, new: $("#s-nova").value });
      mostrar(true, "Senha alterada.");
      setTimeout(() => $("#dlg-senha").close(), 1200);
    } catch (err) { mostrar(false, err.message); }
  }

  function aplicarUsuario() {
    const u = estado.usuario;
    document.body.classList.toggle("viewer", !ehAdmin());
    $("#btn-usuario").textContent = `${u.name} ▾`;
    $("#usuario-info").innerHTML = "";
    const forte = document.createElement("strong");
    forte.textContent = u.name;
    $("#usuario-info").append(forte, document.createTextNode(`${u.username} | ${u.role_label}`));
    if (!ehAdmin() && estado.editando) modoEdicao(false);
  }

  // ------------------------------------------------------------ eventos
  function ligarEventos() {
    $("#periodo").addEventListener("change", (e) => {
      const p = e.target.value;
      salvarLocal("painel.periodo", p);
      aplicarPreset(p);
      if (p !== "custom") recarregar();
    });
    ["#inicio", "#fim"].forEach((s) => $(s).addEventListener("change", () => {
      $("#periodo").value = "custom"; salvarLocal("painel.periodo", "custom");
      salvarLocal("painel.datas", [$("#inicio").value, $("#fim").value]);
      recarregar();
    }));

    $("#btn-tecnicos").addEventListener("click", (e) => { e.stopPropagation(); const m = $("#lista-tecnicos"); const abrir = m.hidden; fecharMenus(null); m.hidden = !abrir; });
    $("#lista-tecnicos").addEventListener("click", (e) => e.stopPropagation());
    document.addEventListener("click", () => fecharMenus(null));
    $("#tec-busca").addEventListener("input", desenharListaTecnicos);
    $("#tec-todos").addEventListener("click", () => { estado.selecionados = new Set(estado.tecnicos.map((t) => t.id)); mudouTecnicos(); });
    $("#tec-nenhum").addEventListener("click", () => { estado.selecionados = new Set(); desenharListaTecnicos(); $("#btn-tecnicos").textContent = "Técnicos: marque ao menos um"; });

    $("#btn-atualizar").addEventListener("click", () => carregarDados(true));
    $("#btn-editar").addEventListener("click", () => modoEdicao(true));
    $("#btn-concluir").addEventListener("click", () => modoEdicao(false));
    $("#btn-add").addEventListener("click", () => abrirEditor(null));
    $("#btn-restaurar").addEventListener("click", async () => {
      if (!confirm("Substituir o painel atual pelo painel padrão?")) return;
      estado.painel = await api("/api/dashboard?default=true");
      salvarPainel(); renderizar();
    });
    $("#btn-config").addEventListener("click", () => abrirConfig());

    [["#btn-exportar", "#menu-exportar"], ["#btn-usuario", "#menu-usuario"]].forEach(([b, m]) => {
      $(b).addEventListener("click", (e) => { e.stopPropagation(); const menu = $(m); const abrir = menu.hidden; fecharMenus(null); menu.hidden = !abrir; });
      $(m).addEventListener("click", (e) => e.stopPropagation());
    });
    $("#exp-pdf").addEventListener("click", () => { fecharMenus(null); exportarPDF(estado.painel.widgets, nomeArquivo("painel_atendimento", "pdf")); });
    $("#exp-csv-chamados").addEventListener("click", () => { fecharMenus(null); exportarCSVChamados(); });
    $("#mu-senha").addEventListener("click", () => { fecharMenus(null); abrirSenha(); });
    $("#mu-usuarios").addEventListener("click", () => { fecharMenus(null); abrirUsuarios(); });
    $("#mu-sair").addEventListener("click", async () => { try { await post("/api/logout"); } finally { window.location.href = "/login"; } });

    $("#form-usuario").addEventListener("submit", salvarUsuario);
    $("#u-novo").addEventListener("click", limparFormUsuario);
    $("#u-fechar").addEventListener("click", () => $("#dlg-usuarios").close());
    $("#form-senha").addEventListener("submit", salvarSenha);
    $("#s-fechar").addEventListener("click", () => $("#dlg-senha").close());

    $("#w-metrica").addEventListener("change", () => {
      const meta = estado.porId[$("#w-metrica").value];
      const antigo = $("#w-titulo").value.trim();
      if (!antigo || estado.metricas.some((m) => m.title === antigo)) $("#w-titulo").value = meta.title;
      $("#w-ajuda").textContent = meta.help;
      preencherTipos(meta.kind, $("#w-tipo").value);
      if (meta.kind === "kpi") { $("#w-largura").value = "3"; $("#w-altura").value = "P"; }
      else {
        if ($("#w-altura").value === "P") $("#w-altura").value = "M";
        if ($("#w-largura").value === "3") $("#w-largura").value = "6";
      }
    });
    $("#form-widget").addEventListener("submit", salvarEditor);
    $("#w-cancelar").addEventListener("click", () => $("#dlg-widget").close());

    $("#c-testar").addEventListener("click", async () => {
      resultado(true, "Testando conexão…");
      try { const r = await post("/api/test", lerFormConfig()); resultado(r.ok, r.message); }
      catch (e) { resultado(false, e.message); }
    });
    $("#c-cancelar").addEventListener("click", () => $("#dlg-config").close());
    $("#form-config").addEventListener("submit", async (e) => {
      e.preventDefault();
      try {
        await post("/api/config", lerFormConfig());
        $("#dlg-config").close();
        estado.tecnicos = [];
        carregarDados(true);
      } catch (err) { resultado(false, err.message); }
    });
  }

  // ------------------------------------------------------------ inicio
  async function iniciar() {
    if (!window.Chart) { aviso("A biblioteca de gráficos não foi carregada. Reconstrua a imagem Docker (docker compose build)."); return; }
    ligarEventos();

    const sel = $("#w-paleta");
    Object.entries(PALETAS).forEach(([k, p]) => sel.add(new Option(p.nome, k)));

    const preset = lerLocal("painel.periodo", "30");
    $("#periodo").value = preset;
    if (preset === "custom") {
      const [i, f] = lerLocal("painel.datas", ["", ""]);
      $("#inicio").value = i; $("#fim").value = f;
      if (!i || !f) { $("#periodo").value = "30"; aplicarPreset("30"); }
    } else aplicarPreset(preset);

    try {
      estado.usuario = await api("/api/me");
      aplicarUsuario();
      const [metricas, painel, cfg] = await Promise.all([api("/api/metric-list"), api("/api/dashboard"), api("/api/config")]);
      estado.metricas = metricas;
      metricas.forEach((m) => { estado.porId[m.id] = m; });
      estado.painel = painel;

      const selM = $("#w-metrica");
      const grupos = {};
      metricas.forEach((m) => {
        if (!grupos[m.group]) { grupos[m.group] = document.createElement("optgroup"); grupos[m.group].label = m.group; selM.appendChild(grupos[m.group]); }
        grupos[m.group].appendChild(new Option(m.title, m.id));
      });

      renderizar();
      if (!cfg.configured && !ehAdmin()) {
        aviso("O painel ainda não foi conectado ao GLPI. Peça a um administrador para fazer a configuração.");
        return;
      }
      if (!cfg.configured) {
        abrirConfig("Bem-vindo! Informe a URL da API e os tokens do GLPI para começar. Use \"Testar conexão\" antes de salvar.");
        return;
      }
      carregarDados(false);
    } catch (e) {
      aviso(`Erro ao iniciar o painel: ${e.message}`);
    }
  }

  iniciar();
})();
